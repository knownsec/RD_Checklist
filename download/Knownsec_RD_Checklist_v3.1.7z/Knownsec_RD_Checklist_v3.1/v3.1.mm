<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1354239686329" ID="ID_846346631" MODIFIED="1463563969010" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="5">&#30693;&#36947;&#21019;&#23431;&#30740;&#21457;&#25216;&#33021;&#34920;v3.1</font>
    </p>
    <p>
      2016/5/18 &#21457;&#24067;
    </p>
    <p>
      by @&#30693;&#36947;&#21019;&#23431;(www.knownsec.com) @&#20313;&#24358; &amp; 404&#22242;&#38431;
    </p>
    <p>
      &#21518;&#32493;&#21160;&#24577;&#35831;&#20851;&#27880;&#24494;&#20449;&#20844;&#20247;&#21495;&#65306;<font color="#cc0000"><b>Lazy-Thought</b></font>
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier"/>
<node CREATED="1366589834644" ID="ID_1668866442" MODIFIED="1438789293506" POSITION="left" TEXT="&#x8bf4;&#x660e;">
<node CREATED="1438697310879" ID="ID_1273342860" MODIFIED="1438697315895" TEXT="&#x5173;&#x4e8e;&#x77e5;&#x9053;&#x521b;&#x5b87;">
<node CREATED="1438697402150" ID="ID_521382123" MODIFIED="1439024009209" TEXT="&#x77e5;&#x884c;&#x5408;&#x4e00; | &#x5b88;&#x6b63;&#x51fa;&#x5947;"/>
<node CREATED="1438697369436" ID="ID_883661561" MODIFIED="1439023915324" TEXT="&#x77e5;&#x9053;&#x521b;&#x5b87;&#x662f;&#x4e00;&#x5bb6;&#x9ed1;&#x5ba2;&#x6587;&#x5316;&#x6d53;&#x539a;&#x7684;&#x5b89;&#x5168;&#x516c;&#x53f8;&#xff0c;&#x613f;&#x666f;&#x662f;&#x8ba9;&#x4e92;&#x8054;&#x7f51;&#x66f4;&#x597d;&#x66f4;&#x5b89;&#x5168;"/>
</node>
<node CREATED="1366589887685" ID="ID_1602686269" MODIFIED="1439024023654" TEXT="&#x672c;&#x6280;&#x80fd;&#x8868;&#x4e3a;&#x77e5;&#x9053;&#x521b;&#x5b87;&#x7814;&#x53d1;&#x5de5;&#x7a0b;&#x5e08;&#x7684;&#x6280;&#x80fd;&#x6811;&#x96c6;&#x5408;&#xff0c;&#x662f;&#x7684;&#xff0c;&#x5f88;&#x5e9e;&#x5927;">
<node CREATED="1366595918933" ID="ID_1009670471" MODIFIED="1439024063237" TEXT="&#x806a;&#x660e;&#x7684;&#x4eba;&#xff0c;&#x4f1a;&#x6839;&#x636e;&#x6bcf;&#x4e2a;tip&#x81ea;&#x9a71;&#x52a8;&#x6269;&#x5c55;"/>
<node CREATED="1366595955245" ID="ID_840652343" MODIFIED="1439024054795" TEXT="&#x4e0d;&#x806a;&#x660e;&#x7684;&#x4eba;&#xff0c;&#x5750;&#x7b49;&#x522b;&#x4eba;&#x624b;&#x628a;&#x624b;&#xff0c;&#x4e0d;&#x4ec5;&#x4e0d;&#x9002;&#x5408;&#x77e5;&#x9053;&#x521b;&#x5b87;&#xff0c;&#x4e5f;&#x4e0d;&#x9002;&#x5408;&#x4efb;&#x4f55;&#x6709;&#x6781;&#x5ba2;&#x7cbe;&#x795e;&#x7684;&#x516c;&#x53f8;"/>
</node>
<node CREATED="1366597165463" ID="ID_788965343" MODIFIED="1366597194773" TEXT="&#x9644;&#x4ef6;&#x6807;&#x5fd7;&#x662f;&#x6211;&#x4eec;&#x63a8;&#x8350;&#x7684;&#x9644;&#x52a0;&#x8d44;&#x6e90;&#xff0c;&#x611f;&#x8c22;&#x8d44;&#x6e90;&#x63d0;&#x4f9b;&#x8005;">
<icon BUILTIN="attach"/>
</node>
<node CREATED="1366597406072" ID="ID_408134061" LINK="Knownsec_RD_Checklist_v3.1.7z" MODIFIED="1463563955980" TEXT="&#x77e5;&#x9053;&#x521b;&#x5b87;&#x7814;&#x53d1;&#x6280;&#x80fd;&#x8868;v3.1&#x79bb;&#x7ebf;&#x7248;&#x6253;&#x5305;&#x4e0b;&#x8f7d;"/>
</node>
<node CREATED="1354257455737" ID="ID_557208710" MODIFIED="1438789281924" POSITION="left" TEXT="&#x901a;&#x7528;&#x6280;&#x80fd;">
<node CREATED="1354257472176" ID="ID_1999124946" MODIFIED="1438414322775" TEXT="&#x516c;&#x53f8;&#x4e0e;&#x4e2a;&#x4eba;">
<node CREATED="1354444721029" ID="ID_1445059870" MODIFIED="1357466329769" TEXT="&#x516c;&#x53f8;&#x662f;&#x76c8;&#x5229;&#x6027;&#x7ec4;&#x7ec7;"/>
<node CREATED="1354444751506" ID="ID_325025304" MODIFIED="1357466329769" TEXT="&#x4e2a;&#x4eba;&#x548c;&#x516c;&#x53f8;&#x5fc5;&#x987b;&#x53cc;&#x8d62;"/>
<node CREATED="1354444855588" ID="ID_191156609" MODIFIED="1366619158294" TEXT="&#x5728;&#x8ba4;&#x540c;&#x516c;&#x53f8;&#x7406;&#x5ff5;&#x4e14;&#x80fd;&#x591f;&#x7ed9;&#x516c;&#x53f8;&#x521b;&#x9020;&#x8db3;&#x591f;&#x4ef7;&#x503c;&#x7684;&#x57fa;&#x7840;&#x4e0a;&#xff0c;&#x4e3a;&#x4e2a;&#x4eba;&#x53d1;&#x5c55;&#x800c;&#x5de5;&#x4f5c;"/>
</node>
<node CREATED="1438697530899" ID="ID_849814424" MODIFIED="1438734494895" TEXT="WHO AM I">
<icon BUILTIN="idea"/>
<node CREATED="1438697534907" ID="ID_104935314" MODIFIED="1438697545937" TEXT="&#x9ed1;&#x5ba2;&#x662f;&#x5b88;&#x6b63;&#x51fa;&#x5947;&#x4e14;&#x5177;&#x5907;&#x521b;&#x9020;&#x529b;&#x7684;&#x7fa4;&#x4f53;">
<node CREATED="1438698557184" ID="ID_1263789803" MODIFIED="1438698667986" TEXT="&#x5b88;&#x6b63;&#x51fa;&#x5947;">
<node CREATED="1438698669572" ID="ID_986379809" MODIFIED="1438698783767" TEXT="&#x8fd9;&#x6761;&#x6b63;&#x9053;/&#x5e95;&#x7ebf;&#x5f97;&#x575a;&#x5b88;"/>
<node CREATED="1438698690672" ID="ID_392154515" MODIFIED="1439024168653" TEXT="&#x4f46;&#x5982;&#x679c;&#x592a;&#x8fc7;&#x6b63;&#x5c31;&#x8fc2;&#x8150;&#x4e86;&#xff0c;&#x4e3a;&#x4e86;&#x641e;&#x5b9a;&#x4efb;&#x52a1;&#x6709;&#x65f6;&#x5f97;&#x51fa;&#x5947;&#x62db;"/>
</node>
<node CREATED="1438698823741" ID="ID_1044932529" MODIFIED="1438698826960" TEXT="&#x521b;&#x9020;&#x529b;">
<node CREATED="1438698829100" ID="ID_394141975" MODIFIED="1438734631620" TEXT="&#x4e00;&#x4e2a;&#x6ca1;&#x6709;&#x521b;&#x9020;&#x529b;&#x7684;&#x4eba;&#x662f;&#x591a;&#x4e48;&#x7684;&#x53ef;&#x601c;&#xff0c;&#x5bf9;&#x4e8e;&#x56e2;&#x961f;&#x6765;&#x8bf4;&#x4e5f;&#x662f;&#x4e00;&#x79cd;&#x803b;&#x8fb1;"/>
<node CREATED="1438698965296" ID="ID_362322854" MODIFIED="1439024210669" TEXT="&#x672c;&#x6280;&#x80fd;&#x8868;&#x7684;&#x672c;&#x8d28;&#x76ee;&#x7684;&#x53ea;&#x6709;&#x4e00;&#x4e2a;&#xff1a;&#x5f15;&#x5bfc;&#x4f60;&#x62e5;&#x6709;&#x8db3;&#x591f;&#x7684;&#x521b;&#x9020;&#x529b;"/>
</node>
</node>
<node CREATED="1438697565270" ID="ID_1789958276" MODIFIED="1438698285737" TEXT="&#x9ed1;&#x5ba2;&#x4e5f;&#x53ef;&#x4ee5;&#x662f;&#x4e00;&#x79cd;&#x601d;&#x7ef4;&#x65b9;&#x5f0f;"/>
<node CREATED="1438697605155" ID="ID_695063247" MODIFIED="1438697624885" TEXT="&#x6211;&#x4eec;&#x9700;&#x8981;&#x5bf9;&#x5f97;&#x8d77;&#x540d;&#x7247;&#x4e0a;&#x7684;&#x90a3;&#x4e2a;&#x5934;&#x8854;&#xff1a;&#x5de5;&#x7a0b;&#x5e08;&#x3001;&#x7814;&#x7a76;&#x5458;"/>
<node CREATED="1366591291692" ID="ID_1745785267" MODIFIED="1438729541540" TEXT="&#x725b;&#x4eba;&#x59ff;&#x6001;">
<node CREATED="1366591333270" ID="ID_1766977017" MODIFIED="1366591354095" TEXT="&#x5373;&#x4f7f;&#x73b0;&#x5728;&#x4e0d;&#x662f;&#x725b;&#x4eba;&#xff0c;&#x4e5f;&#x5f97;&#x5177;&#x5907;&#x8fd9;&#x6837;&#x7684;&#x59ff;&#x6001;"/>
<node CREATED="1366591376594" ID="ID_1015057228" MODIFIED="1366591380030" TEXT="&#x6ca1;&#x6709;&#x4e00;&#x5b9a;&#x624e;&#x5b9e;&#x5185;&#x529f;&#x4e0e;&#x8fdc;&#x89c1;&#x7684;&#x4eba;&#x5f88;&#x5c11;&#x6709;&#x8fd9;&#x6837;&#x7684;&#x59ff;&#x6001;"/>
<node CREATED="1438729570448" ID="ID_1180471533" MODIFIED="1438734538847" TEXT="&#x62e5;&#x6709;&#x4e0d;&#x5c06;&#x5c31;&#x7684;&#x505a;&#x4e8b;&#x98ce;&#x683c;&#xff0c;&#x8fdf;&#x65e9;&#x662f;&#x725b;&#x4eba;"/>
</node>
</node>
<node CREATED="1438699843477" ID="ID_1876013399" MODIFIED="1438699848915" TEXT="&#x5982;&#x4f55;&#x505a;&#x4e8b;">
<node CREATED="1374327700921" ID="ID_1081982370" MODIFIED="1438414399519" TEXT="&#x65b9;&#x6cd5;&#x8bba;">
<icon BUILTIN="idea"/>
<node CREATED="1374327704717" ID="ID_1169356997" MODIFIED="1374327729748" TEXT="&#x5b8c;&#x6210;&#x4e00;&#x4ef6;&#x4e8b;&#x6709;&#x597d;&#x51e0;&#x6761;&#x9014;&#x5f84;&#xff0c;&#x4f18;&#x79c0;&#x7684;&#x4eba;&#x7684;&#x9014;&#x5f84;&#x6700;&#x77ed;"/>
<node CREATED="1374327767929" ID="ID_1811557241" MODIFIED="1374327789879" TEXT="&#x4efb;&#x52a1;&#x62c6;&#x5206;&#x5f88;&#x5bb9;&#x6613;&#x5f97;&#x51fa;&#x505a;&#x4e8b;&#x7684;&#x65b9;&#x6cd5;&#x8bba;"/>
<node CREATED="1394189763262" ID="ID_232347512" MODIFIED="1394189792194" TEXT="&#x597d;&#x7684;&#x300c;&#x65b9;&#x6cd5;&#x8bba;&#x300d;&#x4f1a;&#x8ba9;&#x4f60;&#x5177;&#x5907;&#x66f4;&#x5f3a;&#x7684;&#x300c;&#x521b;&#x9020;&#x529b;&#x300d;&#xff01;">
<node CREATED="1394189801531" ID="ID_862111467" MODIFIED="1394189833613" TEXT="&#x65f6;&#x523b;&#x95ee;&#x81ea;&#x5df1;&#xff1a;&#x300c;&#x662f;&#x5426;&#x5177;&#x5907;&#x521b;&#x9020;&#x529b;&#xff1f;&#x300d;">
<icon BUILTIN="idea"/>
</node>
</node>
</node>
<node CREATED="1374327176314" ID="ID_1450289123" MODIFIED="1438730666801" TEXT="&#x4efb;&#x52a1;&#x62c6;&#x5206;">
<icon BUILTIN="idea"/>
<node CREATED="1374327195935" ID="ID_1766548423" MODIFIED="1374327217973" TEXT="&#x6210;&#x957f;&#x8fc7;&#x7a0b;&#x4f1a;&#x7ecf;&#x5386;&#xff1a;&#x80fd;&#x529b;&#x8d8a;&#x5927;&#x3001;&#x8d23;&#x4efb;&#x8d8a;&#x5927;&#x3001;&#x4e8b;&#x60c5;&#x8d8a;&#x591a;"/>
<node CREATED="1374327220305" ID="ID_1962093233" MODIFIED="1374327264665" TEXT="&#x601d;&#x8def;">
<node CREATED="1374327269472" ID="ID_1770092488" MODIFIED="1374327328834" TEXT="&#x62c6;&#x5206;&#x7ec6;&#x5316;&#x4e3a;&#x591a;&#x4e2a;&#x70b9;"/>
<node CREATED="1374327283633" ID="ID_775324370" MODIFIED="1438731109601" TEXT="&#x6392;&#x597d;&#x4f18;&#x5148;&#x7ea7;">
<node CREATED="1354444226083" ID="ID_227374316" MODIFIED="1438731050589" TEXT="&#x4efb;&#x52a1;&#x56db;&#x8c61;&#x9650;&#xff0c;&#x51b3;&#x5b9a;&#x4f18;&#x5148;&#x7ea7;">
<node CREATED="1354444241710" ID="ID_51203910" MODIFIED="1357466329775" TEXT="&#x7d27;&#x6025;&#x91cd;&#x8981;">
<node CREATED="1438700151771" ID="ID_708179960" MODIFIED="1438700160815" TEXT="&#x8d76;&#x7d27;&#x641e;&#x5b9a;"/>
</node>
<node CREATED="1354444256092" ID="ID_1970634531" MODIFIED="1357466329775" TEXT="&#x91cd;&#x8981;&#x4e0d;&#x7d27;&#x6025;">
<node CREATED="1438700163446" ID="ID_80589263" MODIFIED="1440602906236" TEXT="&#x65f6;&#x523b;&#x4fdd;&#x6301;&#x5173;&#x6ce8;&#xff0c;&#x4ee5;&#x514d;&#x6ca6;&#x4e3a;&#x300c;&#x7d27;&#x6025;&#x91cd;&#x8981;&#x300d;"/>
</node>
<node CREATED="1354444266337" ID="ID_1749279437" MODIFIED="1357466329775" TEXT="&#x7d27;&#x6025;&#x4e0d;&#x91cd;&#x8981;">
<node CREATED="1438700680519" ID="ID_717842934" MODIFIED="1438729489654" TEXT="&#x5c11;&#x5c11;&#x76ca;&#x5584;&#xff0c;&#x5b66;&#x4f1a;&#x62d2;&#x7edd;"/>
</node>
<node CREATED="1354444269413" ID="ID_1827772373" MODIFIED="1357466329775" TEXT="&#x4e0d;&#x7d27;&#x6025;&#x4e0d;&#x91cd;&#x8981;">
<node CREATED="1438700713913" ID="ID_1749684233" MODIFIED="1438729476196" TEXT="&#x9760;&#x81ea;&#x5f8b;"/>
</node>
</node>
</node>
<node CREATED="1438731110238" ID="ID_975068976" MODIFIED="1438731124360" TEXT="SMART&#x539f;&#x5219;">
<node CREATED="1438731125885" ID="ID_1539329234" MODIFIED="1438731134616" TEXT="S&#xff1a;&#x4efb;&#x52a1;&#x662f;&#x5426;&#x660e;&#x786e;">
<node CREATED="1438731408985" ID="ID_988821697" MODIFIED="1438731421161" TEXT="&#x4e0d;&#x660e;&#x786e;&#x7684;&#x4efb;&#x52a1;&#x641e;&#x8d77;&#x6765;&#x5c31;&#x662f;&#x6d6a;&#x8d39;&#x751f;&#x547d;"/>
</node>
<node CREATED="1438731135782" ID="ID_867883632" MODIFIED="1438731143104" TEXT="M&#xff1a;&#x4efb;&#x52a1;&#x662f;&#x5426;&#x53ef;&#x5ea6;&#x91cf;">
<node CREATED="1438731423628" ID="ID_873431890" MODIFIED="1438731524823" TEXT="&#x4e0d;&#x53ef;&#x5ea6;&#x91cf;&#x5982;&#x4f55;&#x4f53;&#x73b0;&#x4ef7;&#x503c;&#xff1f;"/>
</node>
<node CREATED="1438731143715" ID="ID_1275549165" MODIFIED="1438731152332" TEXT="A&#xff1a;&#x4efb;&#x52a1;&#x662f;&#x5426;&#x53ef;&#x641e;&#x5b9a;">
<node CREATED="1438731531899" ID="ID_1940954035" MODIFIED="1438731589771" TEXT="&#x641e;&#x4e0d;&#x5b9a;&#x5c31;&#x4e0d;&#x5e94;&#x8be5;&#x63a5;&#xff0c;&#x63a5;&#x5c31;&#x5f97;&#x6709;&#x9b44;&#x529b;&#x641e;&#x5b9a;"/>
</node>
<node CREATED="1438731152689" ID="ID_884075472" MODIFIED="1438731161821" TEXT="R&#xff1a;&#x4efb;&#x52a1;&#x7684;&#x76f8;&#x5173;&#x6027;&#x5982;&#x4f55;">
<node CREATED="1438731307477" ID="ID_1018518766" MODIFIED="1438731404983" TEXT="&#x51b3;&#x5b9a;&#x4e86;&#x4efb;&#x52a1;&#x7684;&#x4ef7;&#x503c;&#xff0c;&#x76f8;&#x5173;&#x6027;&#x8d8a;&#x9ad8;&#x8d8a;&#x80fd;&#x4f53;&#x73b0;&#x4ef7;&#x503c;&#xff0c;&#x6bd4;&#x5982;&#x8fd9;&#x4e2a;&#x4efb;&#x52a1;&#x641e;&#x5b9a;&#x4e86;&#x80fd;&#x8ba9;&#x56e2;&#x961f;&#x83b7;&#x5f97;&#x516c;&#x53f8;&#x3001;&#x5ba2;&#x6237;&#x7b49;&#x66f4;&#x5927;&#x7684;&#x8ba4;&#x53ef;"/>
</node>
<node CREATED="1438731162079" ID="ID_1338854103" MODIFIED="1438731167407" TEXT="T&#xff1a;&#x4efb;&#x52a1;&#x7684;&#x65f6;&#x95f4;">
<node CREATED="1438731594846" ID="ID_1931737336" MODIFIED="1438731696211" TEXT="Timeline&#xff1a;&#x4efb;&#x52a1;&#x65f6;&#x95f4;&#x8f74;&#xff0c;&#x4ec0;&#x4e48;&#x65f6;&#x95f4;&#x70b9;&#x9700;&#x8981;&#x641e;&#x5b9a;&#x4ec0;&#x4e48;"/>
<node CREATED="1438731698162" ID="ID_1520724097" MODIFIED="1438731728621" TEXT="Deadline&#xff1a;&#x4efb;&#x52a1;&#x7684;&#x6700;&#x540e;&#x671f;&#x9650;&#xff0c;&#x505a;&#x8bc4;&#x4f30;&#x65f6;&#x6700;&#x597d;&#x63d0;&#x524d;&#xff0c;&#x56e0;&#x4e3a;&#x603b;&#x4f1a;&#x6709;&#x5404;&#x79cd;&#x610f;&#x5916;&#x6216;&#x62d6;&#x5ef6;&#x672c;&#x6027;"/>
<node CREATED="1438731739877" ID="ID_733919584" MODIFIED="1438731919052" TEXT="Timeline&#x4e0a;&#x4e00;&#x4e9b;&#x5f88;&#x5173;&#x952e;&#x7684;&#x65f6;&#x95f4;&#x70b9;&#x6211;&#x4eec;&#x53ef;&#x4ee5;&#x79f0;&#x4e3a;&#x91cc;&#x7a0b;&#x7891;&#xff0c;&#x641e;&#x5b9a;&#x6bcf;&#x4e2a;&#x91cc;&#x7a0b;&#x7891;&#x5e94;&#x8be5;&#x5e86;&#x795d;&#x4e0b;"/>
</node>
</node>
<node CREATED="1374327481409" ID="ID_495313193" MODIFIED="1374327500373" TEXT="&#x81ea;&#x5df1;&#x6b20;&#x7f3a;&#x4ec0;&#x4e48;&#xff0c;&#x7acb;&#x9a6c;&#x53d1;&#x73b0;"/>
<node CREATED="1374327384022" ID="ID_261119211" MODIFIED="1438731040033" TEXT="&#x662f;&#x5426;&#x9700;&#x8981;&#x5bfb;&#x6c42;&#x5e2e;&#x52a9;&#xff0c;&#x8c01;&#x80fd;&#x5e2e;&#x4f60;&#xff0c;&#x81ea;&#x5df1;&#x5355;&#x5e72;&#xff1f;">
<arrowlink COLOR="#b0b0b0" DESTINATION="ID_1218170279" ENDARROW="Default" ENDINCLINATION="763;0;" ID="Arrow_ID_1024168527" STARTARROW="None" STARTINCLINATION="763;0;"/>
</node>
<node CREATED="1374327401686" ID="ID_77689631" MODIFIED="1438734373720" TEXT="&#x56e2;&#x961f;">
<node CREATED="1438734409149" ID="ID_863888072" MODIFIED="1438734424827" TEXT="&#x58eb;&#x6c14;&#x7b2c;&#x4e00;"/>
<node CREATED="1438731959789" ID="ID_1537713655" MODIFIED="1438734406147" TEXT="&#x5f53;&#x4f60;&#x6709;&#x56e2;&#x961f;&#x65f6;&#xff0c;&#x5206;&#x914d;&#x4e0e;&#x8c03;&#x5ea6;&#x597d;&#x4efb;&#x52a1;&#x5f88;&#x5173;&#x952e;">
<node CREATED="1438734445178" ID="ID_1767593319" MODIFIED="1438734452617" TEXT="&#x505a;&#x5f97;&#x597d;&#x662f;&#x771f;&#x5e76;&#x53d1;"/>
<node CREATED="1438734452926" ID="ID_1680730003" MODIFIED="1438734458971" TEXT="&#x505a;&#x4e0d;&#x597d;&#x4f1a;&#x6b7b;&#x9501;"/>
</node>
</node>
</node>
</node>
<node CREATED="1354257465854" ID="ID_1218170279" MODIFIED="1438731040033" TEXT="&#x6c9f;&#x901a;&#x3001;&#x53cd;&#x9988;&#x4e0e;&#x8d23;&#x4efb;">
<linktarget COLOR="#b0b0b0" DESTINATION="ID_1218170279" ENDARROW="Default" ENDINCLINATION="763;0;" ID="Arrow_ID_1024168527" SOURCE="ID_261119211" STARTARROW="None" STARTINCLINATION="763;0;"/>
<node CREATED="1354444319461" ID="ID_1820586399" MODIFIED="1438729683116" TEXT="&#x4e00;&#x4e2a;&#x65e0;&#x6c9f;&#x901a;&#x80fd;&#x529b;&#x7684;&#x4eba;&#xff0c;&#x8981;&#x4e48;&#x662f;&#x5929;&#x624d;&#xff0c;&#x8981;&#x4e48;&#x662f;&#x4e0d;&#x53ef;&#x7231;&#x7684;&#x4eba;&#xff0c;&#x4e0d;&#x8fc7;&#x5929;&#x624d;&#x4e5f;&#x5c31;&#x5be5;&#x5be5;&#x65e0;&#x51e0;&#x800c;&#x5df2;&#xff0c;&#x4f60;&#x5e76;&#x4e0d;&#x662f;"/>
<node CREATED="1354521157016" ID="ID_112258221" MODIFIED="1357466329772" TEXT="&#x53cd;&#x9988;&#x8981;&#x53ca;&#x65f6;">
<node CREATED="1354521166124" ID="ID_1939176796" MODIFIED="1357466329772" TEXT="&#x907f;&#x514d;&#x51fa;&#x95ee;&#x9898;&#x4e0d;&#x53cd;&#x9988;&#xff0c;&#x5f71;&#x54cd;&#x8fdb;&#x5ea6;"/>
<node CREATED="1354521211554" ID="ID_1429786201" MODIFIED="1357466329773" TEXT="&#x65b9;&#x5f0f;">
<node CREATED="1354521214124" ID="ID_8006324" MODIFIED="1357466329773" TEXT="&#x6b63;&#x5f0f;&#x7684;&#xff1a;&#x90ae;&#x4ef6;"/>
<node CREATED="1354521217818" ID="ID_244007238" MODIFIED="1438729849459" TEXT="&#x4e34;&#x65f6;&#x7684;&#xff1a;&#x5fae;&#x4fe1;&#x7b49;&#x5373;&#x65f6;&#x901a;&#x4fe1;"/>
<node CREATED="1354521229624" ID="ID_1248535420" MODIFIED="1438729857943" TEXT="&#x7740;&#x6025;&#x7684;&#xff1a;&#x7ed9;&#x4e2a;&#x7535;&#x8bdd;"/>
</node>
</node>
<node CREATED="1354521185644" ID="ID_815830436" MODIFIED="1357466329774" TEXT="&#x5de5;&#x4f5c;&#x6709;&#x5927;&#x5c0f;&#xff0c;&#x8d23;&#x4efb;&#x5fc3;&#x65e0;&#x5927;&#x5c0f;"/>
<node CREATED="1354693513705" ID="ID_670269590" MODIFIED="1357466329774" TEXT="&#x5468;&#x62a5;&#x7684;&#x900f;&#x660e;">
<node CREATED="1354693517313" ID="ID_66316632" MODIFIED="1438730387252" TEXT="&#x610f;&#x4e49;&#xff1a;&#x5927;&#x5bb6;&#x4e92;&#x76f8;&#x4e86;&#x89e3;&#x5de5;&#x4f5c;&#x4e0e;&#x5fc3;&#x5f97;&#xff0c;&#x6709;&#x5229;&#x4e8e;&#x81ea;&#x5df1;&#x7684;&#x5224;&#x65ad;&#x4e0e;&#x6210;&#x957f;">
<node CREATED="1438730388310" ID="ID_1874963209" MODIFIED="1438730398258" TEXT="&#x89c2;&#x5bdf;&#x662f;&#x4e00;&#x79cd;&#x591a;&#x91cd;&#x8981;&#x7684;&#x6280;&#x80fd;"/>
<node CREATED="1438730398944" ID="ID_675182570" MODIFIED="1438730400022" TEXT="&#x4e0d;&#x662f;&#x5355;&#x7eaf;&#x7684;&#x7ed9;&#x9886;&#x5bfc;&#x6c47;&#x62a5;&#x5de5;&#x4f5c;"/>
</node>
<node CREATED="1438729883283" ID="ID_1478173637" MODIFIED="1438730171573" TEXT="&#x5468;&#x62a5;&#x9700;&#x4f53;&#x73b0;&#x672c;&#x5468;&#x5de5;&#x4f5c;&#x603b;&#x7ed3;&#x3001;&#x4e0b;&#x5468;&#x5de5;&#x4f5c;&#x8ba1;&#x5212;&#x3001;&#x5fc3;&#x5f97;/&#x95ee;&#x9898;/&#x5efa;&#x8bae;&#xff08;&#x6211;&#x4eec;&#x53eb;&#x5527;&#x5527;&#x6b6a;&#x6b6a;&#xff09;"/>
<node CREATED="1438730197521" ID="ID_59835418" MODIFIED="1438730208085" TEXT="&#x5468;&#x62a5;&#x53ef;&#x4ee5;&#x5f88;&#x597d;&#x4f53;&#x73b0;&#x4e00;&#x4e2a;&#x4eba;&#x7684;">
<node CREATED="1438730209173" ID="ID_648411246" MODIFIED="1438730212111" TEXT="&#x603b;&#x7ed3;&#x80fd;&#x529b;"/>
<node CREATED="1438730212329" ID="ID_37054422" MODIFIED="1438730214479" TEXT="&#x8ba1;&#x5212;&#x80fd;&#x529b;"/>
<node CREATED="1438730214724" ID="ID_1524189860" MODIFIED="1438730536135" TEXT="&#x5206;&#x4eab;&#x80fd;&#x529b;">
<node CREATED="1438730230491" ID="ID_1002834798" MODIFIED="1438730494706" TEXT="&#x60f3;&#x8c61;&#x4e0b;&#xff1a;&#x4e00;&#x4e2a;&#x4eba;&#x4ece;&#x6765;&#x6ca1;&#x6709;&#x5fc3;&#x5f97;/&#x95ee;&#x9898;/&#x5efa;&#x8bae;&#x7684;&#x6c89;&#x6dc0;&#x6216;&#x53cd;&#x9988;&#xff0c;&#x8fd9;&#x4e2a;&#x4eba;&#x662f;&#x4e00;&#x4e2a;&#x76f8;&#x5bf9;&#x5c01;&#x95ed;&#x7684;&#x4eba;&#xff0c;&#x5728;&#x56e2;&#x961f;&#x4f5c;&#x6218;&#x4e2d;&#x5f88;&#x96be;&#x8fbe;&#x5230;&#x9ed8;&#x5951;"/>
<node CREATED="1438730540504" ID="ID_201229555" MODIFIED="1438730562989" TEXT="&#x5f53;&#x7136;&#xff0c;&#x8fd9;&#x79cd;&#x5206;&#x4eab;&#x80fd;&#x529b;&#x8fdc;&#x4e0d;&#x4ec5;&#x4ec5;&#x662f;&#x5728;&#x5468;&#x62a5;&#x8fd9;&#x79cd;&#x5f62;&#x5f0f;&#x91cc;"/>
</node>
</node>
</node>
</node>
<node CREATED="1439024529157" ID="ID_780612458" MODIFIED="1439024533037" TEXT="&#x56e2;&#x961f;&#x610f;&#x8bc6;">
<node CREATED="1439025079707" ID="ID_535218070" MODIFIED="1439025110599" TEXT="&#x5f88;&#x591a;&#x4eba;&#x90fd;&#x8bf4;&#x81ea;&#x5df1;&#x5177;&#x5907;&#x8db3;&#x591f;&#x597d;&#x7684;&#x56e2;&#x961f;&#x610f;&#x8bc6;&#xff0c;&#x4f46;&#x662f;&#x6709;&#x4e9b;&#x4eba;&#x5374;&#x5e76;&#x4e0d;&#x662f;&#x8fd9;&#x6837;">
<node CREATED="1439024534578" ID="ID_163989112" MODIFIED="1440602880416" TEXT="&#x4e3e;&#x4e2a;&#x5c0f;&#x4f8b;&#x5b50;&#xff1a;&#x4e00;&#x4e2a;10&#x4eba;&#x56e2;&#x961f;&#x7ea6;&#x5b9a;&#x65e9;&#x4e0a;10&#x70b9;&#x5f00;&#x4f1a;&#xff0c;&#x800c;&#x4f60;&#x8fdf;&#x5230;&#x4e86;10&#x5206;&#x949f;&#xff0c;&#x5bf9;&#x4e8e;&#x56e2;&#x961f;&#x6765;&#x8bf4;&#x4f60;&#x6d6a;&#x8d39;&#x4e86;&#x6574;&#x4e2a;&#x56e2;&#x961f;100&#x5206;&#x949f;&#xff08;10&#x4eba;*10&#x5206;&#x949f;&#xff09;&#x7684;&#x751f;&#x547d;&#x3002;&#x6709;&#x4e9b;&#x4eba;&#x65e0;&#x7f9e;&#x6127;&#x4e4b;&#x5fc3;&#x8981;&#x4e48;&#x662f;&#x610f;&#x8bc6;&#x4e0d;&#x5230;&#x8fd9;&#x70b9;&#xff0c;&#x8981;&#x4e48;&#x8fd9;&#x4e2a;&#x56e2;&#x961f;&#x7684;&#x98ce;&#x6c14;&#x5c31;&#x662f;&#x8fd9;&#x6837;..."/>
</node>
<node CREATED="1439024896907" ID="ID_829398325" MODIFIED="1439024931421" TEXT="&#x56e2;&#x961f;&#x610f;&#x8bc6;&#x662f;&#x5efa;&#x7acb;&#x5728;&#x4e92;&#x76f8;&#x4fe1;&#x4efb;&#x7684;&#x57fa;&#x7840;&#x4e0a;"/>
<node CREATED="1439025135954" ID="ID_382055633" MODIFIED="1439025185714" TEXT="Leader&#x6700;&#x5173;&#x952e;&#xff0c;&#x4f18;&#x79c0;&#x7684;Leader&#x4e00;&#x5b9a;&#x4f1a;&#x6709;&#x4e2a;&#x4f18;&#x79c0;&#x56e2;&#x961f;">
<node CREATED="1439025468354" ID="ID_756959576" MODIFIED="1439025481355" TEXT="&#x5175;&#x718a;&#x718a;&#x4e00;&#x4e2a;"/>
<node CREATED="1439025481685" ID="ID_163203881" MODIFIED="1439025489548" TEXT="&#x5c06;&#x718a;&#x718a;&#x4e00;&#x7a9d;"/>
</node>
<node CREATED="1439025529636" ID="ID_1859487669" MODIFIED="1439025551738" TEXT="&#x5982;&#x4f55;&#x62e5;&#x6709;&#x4e2a;&#x4f18;&#x79c0;&#x7684;&#x56e2;&#x961f;&#x662f;&#x4e00;&#x4e2a;&#x590d;&#x6742;&#x7684;&#x8bdd;&#x9898;"/>
</node>
</node>
<node CREATED="1354695004833" ID="ID_493324442" MODIFIED="1438730645969" TEXT="&#x6210;&#x957f;">
<node CREATED="1354694409145" ID="ID_1841177366" MODIFIED="1438734849708" TEXT="&#x65b0;&#x4e8b;&#x7269;&#x7684;&#x654f;&#x611f;&#x6027;">
<node CREATED="1354694462559" ID="ID_1914083475" MODIFIED="1394119172715" TEXT="&#x4fdd;&#x6301;&#x597d;&#x5947;&#x5fc3;"/>
<node CREATED="1354694415302" ID="ID_586113309" MODIFIED="1394119239175" TEXT="&#x4e0d;&#x8981;&#x5c40;&#x9650;&#x5728;&#x81ea;&#x5df1;&#x7684;&#x5708;&#x5b50;&#xff0c;&#x9002;&#x5f53;&#x8de8;&#x754c;&#x5438;&#x6536;&#x7075;&#x611f;"/>
<node CREATED="1438734921823" ID="ID_1039769986" MODIFIED="1463561866175" TEXT="&#x8ba2;&#x9605;&#x56fd;&#x5185;&#x5916;&#x4f18;&#x79c0;&#x535a;&#x5ba2;/&#x8d44;&#x6e90;&#xff0c;Inoreader/&#x6df1;&#x84dd;&#x9605;&#x8bfb;&#x4e0d;&#x9519;"/>
<node CREATED="1354694503450" ID="ID_1709472205" MODIFIED="1357466329776" TEXT="&#x9009;&#x62e9;&#x6027;&#x53c2;&#x4e0e;&#x4e00;&#x4e9b;&#x5fc5;&#x8981;&#x7684;&#x4f1a;&#x8bae;&#xff0c;&#x542c;&#x5fc5;&#x8981;&#x7684;&#x4e3b;&#x9898;&#xff0c;&#x8ba8;&#x8bba;&#x5fc5;&#x8981;&#x7684;&#x8bdd;&#x9898;"/>
</node>
<node CREATED="1438734972110" ID="ID_1525070318" MODIFIED="1438735172311" TEXT="&#x5173;&#x4e8e;&#x77e5;&#x8bc6;">
<icon BUILTIN="idea"/>
<node CREATED="1354695012334" ID="ID_1190843275" MODIFIED="1394189495450" TEXT="&#x5bf9;&#x77e5;&#x8bc6;&#x7684;&#x6e34;&#x671b;&#x7a0b;&#x5ea6;&#x51b3;&#x5b9a;&#x4e86;&#x524d;&#x8fdb;&#x52a8;&#x529b;&#x7684;&#x5927;&#x5c0f;"/>
<node CREATED="1438734989456" ID="ID_946547797" MODIFIED="1438735011476" TEXT="&#x5f53;&#x77e5;&#x8bc6;&#x5f88;&#x5ec9;&#x4ef7;&#x5730;&#x6446;&#x5728;&#x4f60;&#x9762;&#x524d;&#xff0c;&#x4f60;&#x53cd;&#x800c;&#x4e0d;&#x4f1a;&#x73cd;&#x60dc;"/>
<node CREATED="1438734980287" ID="ID_992415401" MODIFIED="1438734988895" TEXT="&#x5bf9;&#x77e5;&#x8bc6;&#x4fdd;&#x6301;&#x656c;&#x754f;&#x4e4b;&#x5fc3;"/>
</node>
<node CREATED="1354695195117" ID="ID_454956981" MODIFIED="1438735096777" TEXT="&#x4e0d;&#x8981;&#x8ba9;&#x81ea;&#x5df1;&#x6210;&#x4e3a;&#x77eb;&#x60c5;/&#x6d6e;&#x5938;&#x7684;&#x4eba;"/>
<node CREATED="1354695943181" ID="ID_369132035" MODIFIED="1366619241707" TEXT="&#x548c;&#x6bd4;&#x4f60;&#x5389;&#x5bb3;&#x7684;&#x4eba;&#x5728;&#x4e00;&#x8d77;&#xff0c;&#x548c;&#x4e00;&#x6d41;&#x7684;&#x4eba;&#x5de5;&#x4f5c;">
<node CREATED="1354695978581" ID="ID_1514285611" MODIFIED="1357466329777" TEXT="&#x6307;&#x70b9;&#x5f80;&#x5f80;&#x662f;&#x7cbe;&#x534e;"/>
<node CREATED="1366619247089" ID="ID_1687264716" MODIFIED="1394341544521" TEXT="&#x675c;&#x7edd;&#x7b28;&#x86cb;&#x7206;&#x70b8;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1366619255876" ID="ID_920046021" MODIFIED="1366619267916" TEXT="&#x4e8c;&#x6d41;&#x7684;&#x4eba;&#x62db;&#x8fdb;&#x6765;&#x7684;&#x4eba;&#x4e0d;&#x592a;&#x53ef;&#x80fd;&#x662f;&#x4e00;&#x6d41;&#x7684;"/>
<node CREATED="1438735113144" ID="ID_140121228" MODIFIED="1438735123698" TEXT="&#x4e45;&#x800c;&#x4e45;&#x4e4b;&#x4e00;&#x4e2a;&#x56e2;&#x961f;&#x5c31;&#x7b28;&#x86cb;&#x7206;&#x70b8;&#x4e86;"/>
</node>
</node>
<node CREATED="1354695208770" ID="ID_924094943" MODIFIED="1357466329777" TEXT="&#x601d;&#x8003;">
<node CREATED="1354695276875" ID="ID_1520431041" MODIFIED="1357466329777" TEXT="&#x6279;&#x5224;&#x6027;&#x601d;&#x8003;"/>
<node CREATED="1354695280082" ID="ID_867798815" MODIFIED="1357466329778" TEXT="&#x6362;&#x4f4d;&#x601d;&#x8003;">
<node CREATED="1439026754819" ID="ID_289746279" MODIFIED="1439027188727" TEXT="&#x5bf9;&#x4e8e;&#x4e00;&#x4e2a;&#x56e2;&#x961f;&#x6765;&#x8bf4;&#xff0c;&#x8fd9;&#x70b9;&#x592a;&#x5173;&#x952e;"/>
</node>
</node>
<node CREATED="1394120864924" ID="ID_617449361" MODIFIED="1394120922431" TEXT="&#x63d0;&#x95ee;&#x7684;&#x667a;&#x6167;">
<icon BUILTIN="idea"/>
<node CREATED="1394120896822" ID="ID_977455089" MODIFIED="1439027209454" TEXT="&#x9047;&#x5230;&#x95ee;&#x9898;&#x5148;&#x72ec;&#x7acb;&#x601d;&#x8003;&#xff0c;&#x5c1d;&#x8bd5;&#x72ec;&#x7acb;&#x89e3;&#x51b3;&#xff0c;&#x5c3d;&#x6700;&#x5927;&#x52aa;&#x529b;&#x540e;&#x518d;&#x63d0;&#x95ee;"/>
<node CREATED="1439026961863" ID="ID_884677926" MODIFIED="1439027350919" TEXT="&#x63d0;&#x95ee;&#x65f6;&#xff0c;&#x793c;&#x8c8c;&#x5f88;&#x5173;&#x952e;&#xff08;&#x5bf9;&#x77e5;&#x8bc6;&#x7684;&#x656c;&#x754f;&#xff09;&#xff0c;&#x6e05;&#x6670;&#x8868;&#x8fbe;&#x5f88;&#x5173;&#x952e;"/>
<node CREATED="1439027131456" ID="ID_1001659865" MODIFIED="1439027161853" TEXT="&#x89e3;&#x51b3;&#x540e;&#xff0c;&#x5206;&#x4eab;&#x51fa;&#x6765;&#x5e2e;&#x52a9;&#x66f4;&#x591a;&#x9700;&#x8981;&#x5e2e;&#x52a9;&#x7684;&#x4eba;"/>
</node>
<node CREATED="1374323814214" ID="ID_574386996" MODIFIED="1374326928145" TEXT="&#x5c0f;&#x4e8b;&#x5fc3;&#x6001;">
<icon BUILTIN="idea"/>
<node CREATED="1374323825282" ID="ID_241653602" MODIFIED="1439027241909" TEXT="&#x8d8a;&#x57fa;&#x7840;&#x7684;&#x4e8b;&#x8d8a;&#x5173;&#x952e;&#xff0c;&#x8d8a;&#x9700;&#x8981;&#x7ec6;&#x5fc3;"/>
<node CREATED="1374323849181" ID="ID_793690587" MODIFIED="1394119539870" TEXT="&#x4e0d;&#x8981;&#x4e00;&#x5473;&#x76f2;&#x76ee;&#x8ffd;&#x6c42;&#x300c;&#x9ad8;&#x7ea7;&#x611f;&#x300d;&#xff0c;&#x800c;&#x5ffd;&#x89c6;&#x300c;&#x5c0f;&#x4e8b;&#x300d;/&#x300c;&#x7b80;&#x5355;&#x4e8b;&#x300d;/&#x300c;&#x57fa;&#x7840;&#x4e8b;&#x300d;"/>
<node CREATED="1374323922222" ID="ID_1589699924" MODIFIED="1374323929807" TEXT="&#x57fa;&#x7840;&#x4e0d;&#x7262;&#x3001;&#x5730;&#x52a8;&#x5c71;&#x6447;"/>
<node CREATED="1374324801658" ID="ID_1058090728" MODIFIED="1374324829411" TEXT="&#x5c0f;&#x4e8b;&#x505a;&#x4e0d;&#x597d;&#xff0c;&#x522b;&#x63d0;&#x5927;&#x4e8b;"/>
</node>
<node CREATED="1439027272399" ID="ID_838706997" MODIFIED="1439027391719" TEXT="&#x65e0;&#x8bba;&#x662f;&#x4e2a;&#x4eba;&#x8fd8;&#x662f;&#x56e2;&#x961f;&#x7684;&#x6210;&#x957f;&#x90fd;&#x9700;&#x8981;&#x4e0d;&#x65ad;&#x6c89;&#x6dc0;&#x77e5;&#x8bc6;&#xff0c;&#x6ca1;&#x6709;&#x6c89;&#x6dc0;&#x6839;&#x57fa;&#x4e0d;&#x7a33;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
<node CREATED="1354444432229" ID="ID_288712132" MODIFIED="1438735202692" TEXT="&#x5b8c;&#x6210;&#x7684;&#x5b9a;&#x4e49;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1354444436498" ID="ID_1322929539" MODIFIED="1440639938973" TEXT="&#x6bd4;&#x5982;&#x5199;&#x4e2a;PoC">
<node CREATED="1354444477365" ID="ID_1887957488" MODIFIED="1354675233656" TEXT="1. &#x641e;&#x61c2;&#x4e86;&#x76ee;&#x6807;Web&#x5e94;&#x7528;&#x6f0f;&#x6d1e;&#x7684;&#x539f;&#x7406;"/>
<node CREATED="1354444505318" ID="ID_1486263751" MODIFIED="1354675233656" TEXT="2. &#x719f;&#x7ec3;&#x8fd0;&#x7528;Python&#x5404;&#x76f8;&#x5173;&#x6a21;&#x5757;&#x4e0e;&#x673a;&#x5236;"/>
<node CREATED="1354444569138" ID="ID_1190374366" MODIFIED="1354675233666" TEXT="3. &#x719f;&#x7ec3;&#x4e86;&#x89e3;&#x4e86;HTTP&#x534f;&#x8bae;">
<node CREATED="1354444578617" ID="ID_1408162296" MODIFIED="1354675233666" TEXT="HTTP&#x8bf7;&#x6c42;"/>
<node CREATED="1354444582595" ID="ID_1202773949" MODIFIED="1354675233666" TEXT="HTTP&#x54cd;&#x5e94;"/>
</node>
<node CREATED="1354444595233" ID="ID_1180509269" MODIFIED="1354675233666" TEXT="4. &#x4ee3;&#x7801;&#x5199;&#x5f97;&#x591f;&#x89c4;&#x8303;&#xff0c;&#x8ba9;&#x4eba;&#x770b;&#x8d77;&#x6765;&#x5c31;&#x662f;&#x723d;"/>
<node CREATED="1354444616761" ID="ID_1310775860" MODIFIED="1354675233666" TEXT="5. &#x7a0b;&#x5e8f;&#x7ecf;&#x8fc7;&#x8db3;&#x591f;&#x7684;&#x6d4b;&#x8bd5;">
<node CREATED="1354444634799" ID="ID_1023901233" MODIFIED="1354675233666" TEXT="&#x9ed1;&#x6d4b;&#x8bd5;"/>
<node CREATED="1354444636681" ID="ID_616363270" MODIFIED="1354675233666" TEXT="&#x767d;&#x6d4b;&#x8bd5;"/>
</node>
<node CREATED="1354444641608" ID="ID_1634425614" MODIFIED="1354675233666" TEXT="6. &#x53ca;&#x65f6;&#x53cd;&#x9988;&#x8fdb;&#x5ea6;">
<node CREATED="1354444655894" ID="ID_1359168916" MODIFIED="1354675233666" TEXT="&#x6211;&#x9047;&#x5230;&#x56f0;&#x96be;&#x4e86;"/>
<node CREATED="1354444660884" ID="ID_186419654" MODIFIED="1354675233666" TEXT="&#x6211;&#x641e;&#x5b9a;&#x4e86;"/>
</node>
<node CREATED="1394120989081" ID="ID_1283195579" MODIFIED="1394121003707" TEXT="7. &#x66f4;&#x65b0;&#x76f8;&#x5173;&#x6587;&#x6863;&#xff0c;&#x6c89;&#x6dc0;"/>
</node>
</node>
<node CREATED="1366620434960" ID="ID_1148338025" MODIFIED="1438735206344" TEXT="&#x719f;&#x7ec3;&#x7684;&#x5b9a;&#x4e49;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1366620443810" ID="ID_1511813132" MODIFIED="1366620521014" TEXT="&#x6bd4;&#x5982;&#x719f;&#x7ec3;SQL&#x6ce8;&#x5165;">
<node CREATED="1366620857549" ID="ID_61260983" MODIFIED="1366620884353" TEXT="SQL&#x8bed;&#x53e5;&#x8fd9;&#x95e8;&#x201c;&#x8bed;&#x8a00;&#x201d;&#x80fd;&#x8131;&#x79bb;&#x6587;&#x6863;&#x987a;&#x624b;&#x5199;&#x51fa;"/>
<node CREATED="1366620451751" ID="ID_1190620162" MODIFIED="1366620513468" TEXT="&#x4e3b;&#x6d41;&#x6570;&#x636e;&#x5e93;&#x7684;SQL&#x7279;&#x6709;&#x51fd;&#x6570;&#x3001;&#x5b58;&#x50a8;&#x8fc7;&#x7a0b;&#x3001;&#x673a;&#x5236;&#x6211;&#x90fd;&#x4e86;&#x5982;&#x6307;&#x638c;">
<node CREATED="1366620524528" ID="ID_888170932" MODIFIED="1366620526261" TEXT="MySQL"/>
<node CREATED="1366620526883" ID="ID_974774379" MODIFIED="1366620529295" TEXT="MSSQL"/>
<node CREATED="1366620529603" ID="ID_1160245706" MODIFIED="1440727563137" TEXT="Oracle"/>
<node CREATED="1366620532100" ID="ID_448133549" MODIFIED="1440639929044" STYLE="fork" TEXT="PostgreSQL"/>
<node CREATED="1366620622144" ID="ID_948380701" MODIFIED="1366620624188" TEXT="Access"/>
<node CREATED="1366620624377" ID="ID_1170276523" MODIFIED="1366620644920" TEXT="SQLite"/>
<node CREATED="1366620734948" ID="ID_838283455" MODIFIED="1366620735698" TEXT="..."/>
</node>
<node CREATED="1366620667101" ID="ID_674202158" MODIFIED="1366620710224" TEXT="&#x725b;&#x903c;&#x7684;&#x5de5;&#x5177;&#x6211;&#x4e0d;&#x4ec5;&#x7528;&#x7684;&#x987a;&#x5176;&#x81ea;&#x7136;&#xff0c;&#x6e90;&#x7801;&#x8fd8;&#x8bfb;&#x8fc7;&#x51e0;&#x904d;&#xff0c;&#x6211;&#x80fd;&#x4fee;&#x6539;">
<node CREATED="1366620712715" ID="ID_1441225326" MODIFIED="1366620725591" TEXT="sqlmap"/>
<node CREATED="1366620730238" ID="ID_1133962922" MODIFIED="1366620731034" TEXT="..."/>
</node>
<node CREATED="1366620748832" ID="ID_1912748369" MODIFIED="1366620964876" TEXT="&#x6211;&#x5177;&#x5907;&#x521b;&#x9020;&#x6027;&#xff0c;&#x800c;&#x4e0d;&#x4ec5;&#x4ec5;&#x662f;&#x8ddf;&#x5728;&#x5927;&#x725b;&#x8eab;&#x540e;">
<node CREATED="1366620811418" ID="ID_1701731143" MODIFIED="1366620820140" TEXT="&#x7814;&#x7a76;&#x51fa;&#x4e86;&#x51e0;&#x4e2a;&#x4e0d;&#x9519;&#x7684;&#x6280;&#x5de7;"/>
<node CREATED="1366620772953" ID="ID_1800111082" MODIFIED="1366620782904" TEXT="&#x53d1;&#x4e86;&#x51e0;&#x7bc7;&#x4e0d;&#x9519;&#x7684;Paper"/>
<node CREATED="1366620783094" ID="ID_675171426" MODIFIED="1366620845571" TEXT="&#x5bf9;&#x5916;&#x4f1a;&#x8bae;/&#x6c99;&#x9f99;&#x7b49;&#x8fdb;&#x884c;&#x4e86;&#x51e0;&#x6b21;&#x5206;&#x4eab;"/>
<node CREATED="1366620927004" ID="ID_49917839" MODIFIED="1366620938835" TEXT="&#x5199;&#x51fa;&#x4e86;&#x81ea;&#x5df1;&#x7684;&#x76f8;&#x5173;&#x5de5;&#x5177;&#xff0c;&#x723d;"/>
</node>
<node CREATED="1366620982731" ID="ID_1279947497" MODIFIED="1366621020973" TEXT="&#x6211;&#x5b9e;&#x6218;&#x4e86;N&#x56de;&#xff0c;&#x9047;&#x5230;&#x4e86;&#x5f88;&#x591a;&#x5947;&#x8469;&#x73af;&#x5883;&#xff0c;&#x6211;&#x6709;&#x8db3;&#x591f;&#x7684;&#x4fe1;&#x5fc3;&#x7ed5;&#x8fc7;"/>
<node CREATED="1366621040743" ID="ID_1080367319" MODIFIED="1366621056012" TEXT="&#x4ee5;&#x4e0a;&#x8fd9;&#x4e9b;&#x4e4b;&#x540e;&#xff0c;&#x8fd9;&#x624d;&#x53eb;&#x719f;&#x7ec3;&#xff01;&#x5176;&#x4ed6;&#x540c;&#x7406;"/>
</node>
</node>
<node CREATED="1357447371872" ID="ID_1851504896" MODIFIED="1438789288424" TEXT="&#x597d;&#x4e66;&#x63a8;&#x8350;">
<node CREATED="1366589141648" ID="ID_548661280" MODIFIED="1366589145607" TEXT="&#x63a8;&#x8350;&#x7406;&#x7531;">
<node CREATED="1366589156199" ID="ID_134347955" MODIFIED="1366589184937" TEXT="&#x6253;&#x901a;&#x4efb;&#x7763;&#x4e8c;&#x8109;&#x7684;&#x4e66;&#xff0c;&#x600e;&#x80fd;&#x4e0d;&#x770b;&#xff1f;">
<node CREATED="1439027484220" ID="ID_1188656883" MODIFIED="1439027511671" TEXT="&#x4f46;&#xff0c;&#x5c3d;&#x4fe1;&#x4e66;&#x4e0d;&#x5982;&#x65e0;&#x4e66;"/>
</node>
<node CREATED="1366589316146" ID="ID_279595981" MODIFIED="1366589352273" TEXT="&#x4efb;&#x4f55;&#x79d1;&#x5b66;&#x7814;&#x7a76;&#x6700;&#x7ec8;&#x5fc5;&#x987b;&#x81f3;&#x5c11;&#x5230;&#x54f2;&#x5b66;&#x5c42;&#x9762;&#xff0c;&#x89e6;&#x78b0;&#x5230;&#x4e0a;&#x5e1d;&#x7684;&#x811a;"/>
<node CREATED="1366589366107" ID="ID_386635510" MODIFIED="1439027430295" TEXT="&#x5177;&#x4f53;&#x6280;&#x672f;&#x7c7b;&#x4e66;&#x7c4d;&#x8bf7;&#x89c1;&#x300c;&#x4e13;&#x4e1a;&#x6280;&#x80fd;&#x300d;&#x76f8;&#x5173;&#x90e8;&#x5206;"/>
</node>
<node CREATED="1394120238548" ID="ID_564231050" MODIFIED="1394120244464" TEXT="&#x9e21;&#x6c64;&#x7c7b;">
<node CREATED="1357447378007" ID="ID_393721136" MODIFIED="1357466329778" TEXT="&#x9ed1;&#x5ba2;&#x4e0e;&#x753b;&#x5bb6;">
<node CREATED="1357449592293" ID="ID_1064350241" MODIFIED="1438735224334" TEXT="&#x5370;&#x8c61;&#x6df1;&#x523b;&#xff1a;&#x8bbe;&#x8ba1;&#x8005;&#x7684;&#x54c1;&#x5473;">
<node CREATED="1357449657570" ID="ID_732401001" MODIFIED="1357449662497" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x662f;&#x7b80;&#x5355;&#x7684;&#x8bbe;&#x8ba1;">
<node CREATED="1357449680161" ID="ID_1472055262" MODIFIED="1357449683119" TEXT="&#x6293;&#x4f4f;&#x672c;&#x8d28;"/>
</node>
<node CREATED="1357449684033" ID="ID_933692566" MODIFIED="1357449690035" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x662f;&#x6c38;&#x4e0d;&#x8fc7;&#x65f6;&#x7684;&#x8bbe;&#x8ba1;">
<node CREATED="1357449782332" ID="ID_550135197" MODIFIED="1357449783339" TEXT="&#x5982;&#x679c;&#x89e3;&#x51b3;&#x65b9;&#x6cd5;&#x662f;&#x4e11;&#x964b;&#x7684;&#xff0c;&#x90a3;&#x5c31;&#x80af;&#x5b9a;&#x8fd8;&#x6709;&#x66f4;&#x597d;&#x7684;&#x89e3;&#x51b3;&#x65b9;&#x6cd5;&#xff0c;&#x53ea;&#x662f;&#x8fd8;&#x6ca1;&#x6709;&#x53d1;&#x73b0;&#x800c;&#x5df2;"/>
</node>
<node CREATED="1357449825146" ID="ID_1334221430" MODIFIED="1357449843400" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x662f;&#x89e3;&#x51b3;&#x4e3b;&#x8981;&#x95ee;&#x9898;&#x7684;&#x8bbe;&#x8ba1;"/>
<node CREATED="1357449879443" ID="ID_430354834" MODIFIED="1357449884921" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x662f;&#x542f;&#x53d1;&#x6027;&#x7684;&#x8bbe;&#x8ba1;"/>
<node CREATED="1357449956220" ID="ID_1621205180" MODIFIED="1357449965370" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x901a;&#x5e38;&#x662f;&#x6709;&#x70b9;&#x8da3;&#x5473;&#x6027;&#x7684;&#x8bbe;&#x8ba1;"/>
<node CREATED="1357449997911" ID="ID_1938039906" MODIFIED="1357450003093" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x662f;&#x8270;&#x82e6;&#x7684;&#x8bbe;&#x8ba1;"/>
<node CREATED="1357450040769" ID="ID_1079176737" MODIFIED="1357450046787" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x662f;&#x770b;&#x4f3c;&#x5bb9;&#x6613;&#x7684;&#x8bbe;&#x8ba1;"/>
<node CREATED="1357450078968" ID="ID_1504316422" MODIFIED="1357450085198" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x662f;&#x5bf9;&#x79f0;&#x7684;&#x8bbe;&#x8ba1;"/>
<node CREATED="1357450101109" ID="ID_1846599686" MODIFIED="1357450108251" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x662f;&#x6a21;&#x4eff;&#x5927;&#x81ea;&#x7136;&#x7684;&#x8bbe;&#x8ba1;"/>
<node CREATED="1357450124098" ID="ID_1509582091" MODIFIED="1357450128890" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x662f;&#x4e00;&#x79cd;&#x518d;&#x8bbe;&#x8ba1;"/>
<node CREATED="1357450141149" ID="ID_1103130466" MODIFIED="1357450147204" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x662f;&#x80fd;&#x591f;&#x590d;&#x5236;&#x7684;&#x8bbe;&#x8ba1;"/>
<node CREATED="1357450176353" ID="ID_1144602577" MODIFIED="1357450182152" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x5f80;&#x5f80;&#x662f;&#x5947;&#x7279;&#x7684;&#x8bbe;&#x8ba1;"/>
<node CREATED="1357450208466" ID="ID_1875898004" MODIFIED="1357450218685" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x662f;&#x6210;&#x6279;&#x51fa;&#x73b0;&#x7684;"/>
<node CREATED="1357450235586" ID="ID_71811231" MODIFIED="1357450241985" TEXT="&#x597d;&#x8bbe;&#x8ba1;&#x5e38;&#x5e38;&#x662f;&#x5927;&#x80c6;&#x7684;&#x8bbe;&#x8ba1;"/>
</node>
</node>
<node CREATED="1357448308127" ID="ID_1252505535" MODIFIED="1357466329779" TEXT="&#x6d6a;&#x6f6e;&#x4e4b;&#x5dc5;">
<node CREATED="1366588772067" ID="ID_686329848" MODIFIED="1366588829068" TEXT="&#x611f;&#x53d7;IT&#x5e1d;&#x56fd;&#x7684;&#x5d1b;&#x8d77;&#x4e0e;&#x6ca1;&#x843d;&#xff0c;&#x6211;&#x4eec;&#x73b0;&#x5728;&#x7ad9;&#x5728;&#x53c8;&#x4e00;&#x4e2a;&#x4e92;&#x8054;&#x7f51;&#x6d6a;&#x6f6e;&#x4e4b;&#x5dc5;"/>
</node>
</node>
<node CREATED="1394120096958" ID="ID_1391794158" MODIFIED="1394120235064" TEXT="&#x6d01;&#x7656;&#x7c7b;">
<node CREATED="1394119891516" ID="ID_241642921" MODIFIED="1394119893323" TEXT="&#x91cd;&#x6784;"/>
<node CREATED="1394119893724" ID="ID_853352702" MODIFIED="1394119899691" TEXT="&#x4ee3;&#x7801;&#x6574;&#x6d01;&#x4e4b;&#x9053;"/>
<node CREATED="1366589099939" ID="ID_1084265394" MODIFIED="1366589102959" TEXT="&#x4ee3;&#x7801;&#x5927;&#x5168;2"/>
</node>
<node CREATED="1394120113889" ID="ID_1456919396" MODIFIED="1394120237956" TEXT="&#x654f;&#x6377;&#x7c7b;">
<node CREATED="1394119984975" ID="ID_635212677" MODIFIED="1394119990128" TEXT="Rework&#x4e2d;&#x6587;&#x7248;">
<node CREATED="1394120056261" ID="ID_1511138717" MODIFIED="1394120083049" TEXT="37signals&#x56e2;&#x961f;&#x7684;&#x654f;&#x6377;&#x7ecf;&#x9a8c;"/>
</node>
<node CREATED="1366589059494" ID="ID_421623152" MODIFIED="1366589060339" TEXT="&#x9ad8;&#x6548;&#x7a0b;&#x5e8f;&#x5458;&#x7684;45&#x4e2a;&#x4e60;&#x60ef;"/>
</node>
<node CREATED="1366588833873" ID="ID_228897562" MODIFIED="1394120175806" TEXT="&#x4ea7;&#x54c1;&#x7c7b;">
<node CREATED="1366588847795" ID="ID_1182474365" MODIFIED="1366588852221" TEXT="&#x4eba;&#x4eba;&#x90fd;&#x662f;&#x4ea7;&#x54c1;&#x7ecf;&#x7406;"/>
<node CREATED="1366588736432" ID="ID_396621642" MODIFIED="1366588739101" TEXT="&#x7ed3;&#x7f51;"/>
</node>
<node CREATED="1366588870577" ID="ID_1362700778" MODIFIED="1366588875553" TEXT="&#x795e;&#x4e66;">
<node CREATED="1366588988264" ID="ID_1712656708" MODIFIED="1366588992681" TEXT="&#x81ea;&#x79c1;&#x7684;&#x57fa;&#x56e0;"/>
<node CREATED="1366588876253" ID="ID_739859006" MODIFIED="1366588884433" TEXT="&#x5931;&#x63a7;"/>
</node>
<node CREATED="1366619362264" ID="ID_474287160" MODIFIED="1366619364699" TEXT="..."/>
</node>
</node>
<node CREATED="1354455662710" ID="ID_1029110524" MODIFIED="1438787869355" POSITION="right" TEXT="&#x4e13;&#x4e1a;&#x6280;&#x80fd;">
<node CREATED="1354522141826" ID="ID_900035370" MODIFIED="1357466329780" TEXT="&#x539f;&#x5219;">
<icon BUILTIN="idea"/>
<node CREATED="1354522148432" ID="ID_679421342" MODIFIED="1357466329780" TEXT="&#x81f3;&#x5c11;&#x5b8c;&#x6574;&#x770b;&#x5b8c;&#x4e0e;&#x7ec3;&#x4e60;&#x597d;&#x4e00;&#x672c;&#x4e66;"/>
<node CREATED="1354522171860" ID="ID_1869570880" MODIFIED="1357466329780" TEXT="&#x81f3;&#x5c11;&#x8fc7;&#x4e00;&#x904d;&#x5b98;&#x65b9;&#x6587;&#x6863;"/>
</node>
<node CREATED="1354674401161" ID="ID_507452271" MODIFIED="1438936569328" TEXT="&#x57fa;&#x7840;&#x5fc5;&#x5907;">
<icon BUILTIN="bookmark"/>
<node CREATED="1354673626222" ID="ID_1399585852" MODIFIED="1354675233676" TEXT="HTTP&#x6293;&#x5305;&#x4e0e;&#x8c03;&#x8bd5;">
<node CREATED="1354673656788" ID="ID_335514646" MODIFIED="1394121148798" TEXT="Firefox&#x63d2;&#x4ef6;">
<node CREATED="1354673790435" ID="ID_1421238729" MODIFIED="1394121167611" TEXT="Firebug">
<node CREATED="1354673858675" ID="ID_395844436" MODIFIED="1354675233676" TEXT="&#x6293;&#x5305;&#x4e0e;&#x5404;&#x79cd;&#x8c03;&#x8bd5;"/>
</node>
<node CREATED="1354673796286" ID="ID_230505824" MODIFIED="1394121222701" TEXT="Tamper Data">
<node CREATED="1354673853994" ID="ID_1381604012" MODIFIED="1354675233676" TEXT="&#x62e6;&#x622a;&#x4fee;&#x6539;"/>
</node>
<node CREATED="1354673799927" ID="ID_1542036775" MODIFIED="1394121232394" TEXT="Live Http Header">
<node CREATED="1354673842654" ID="ID_963420360" MODIFIED="1354675233676" TEXT="&#x91cd;&#x653e;&#x529f;&#x80fd;"/>
</node>
<node CREATED="1354673870639" ID="ID_1838790421" MODIFIED="1394121238226" TEXT="Hackbar">
<node CREATED="1354673876882" ID="ID_1593547764" MODIFIED="1354675233676" TEXT="&#x7f16;&#x7801;&#x89e3;&#x7801;/POST&#x63d0;&#x4ea4;"/>
</node>
<node CREATED="1354674135293" ID="ID_1304690885" MODIFIED="1394121247289" TEXT="Modify Headers">
<node CREATED="1354674150520" ID="ID_838379270" MODIFIED="1354675233676" TEXT="&#x4fee;&#x6539;&#x5934;&#x90e8;"/>
</node>
</node>
<node CREATED="1354674223798" ID="ID_1811648689" MODIFIED="1394121156548" TEXT="Fiddler">
<node CREATED="1354674227898" ID="ID_1352052241" MODIFIED="1354675233686" TEXT="&#x6d4f;&#x89c8;&#x5668;&#x4ee3;&#x7406;&#x795e;&#x5668;"/>
<node CREATED="1354674234772" ID="ID_105794071" MODIFIED="1354675233686" TEXT="&#x62e6;&#x622a;&#x8bf7;&#x6c42;&#x6216;&#x54cd;&#x5e94;"/>
<node CREATED="1354674248955" ID="ID_91213705" MODIFIED="1354675233686" TEXT="&#x6293;&#x5305;"/>
<node CREATED="1354674253255" ID="ID_17804703" MODIFIED="1354675233686" TEXT="&#x91cd;&#x653e;"/>
<node CREATED="1354674264402" ID="ID_605483050" MODIFIED="1354675233686" TEXT="&#x6a21;&#x62df;&#x8bf7;&#x6c42;"/>
<node CREATED="1354674271770" ID="ID_168731266" MODIFIED="1354675233686" TEXT="&#x7f16;&#x7801;&#x89e3;&#x7801;"/>
<node CREATED="1354674278285" ID="ID_930350556" MODIFIED="1354675233686" TEXT="&#x7b2c;&#x4e09;&#x65b9;&#x6269;&#x5c55;">
<node CREATED="1354674293179" ID="ID_1915130627" MODIFIED="1394121257188" TEXT="Watcher">
<node CREATED="1354674298459" ID="ID_1094279668" MODIFIED="1354675233686" TEXT="Web&#x524d;&#x7aef;&#x5b89;&#x5168;&#x7684;&#x81ea;&#x52a8;&#x5ba1;&#x8ba1;&#x5de5;&#x5177;"/>
</node>
</node>
</node>
<node CREATED="1354674312527" ID="ID_1391904023" MODIFIED="1394121262758" TEXT="Wireshark">
<node CREATED="1354674324664" ID="ID_59923656" MODIFIED="1354675233686" TEXT="&#x5404;&#x79cd;&#x5f3a;&#x5927;&#x7684;&#x8fc7;&#x6ee4;&#x5668;&#x8bed;&#x6cd5;"/>
</node>
<node CREATED="1354674320974" ID="ID_155450371" MODIFIED="1394121269617" TEXT="Tcpdump">
<node CREATED="1354674371810" ID="ID_747894351" MODIFIED="1394121274683" TEXT="&#x547d;&#x4ee4;&#x884c;&#x7684;&#x7c7b;Wireshark&#x6293;&#x5305;&#x795e;&#x5668;"/>
</node>
<node CREATED="1354674408173" ID="ID_1101388379" MODIFIED="1394121281233" TEXT="Python">
<node CREATED="1354674412298" ID="ID_210771340" MODIFIED="1354675233686" TEXT="urllib2">
<node CREATED="1322703917516" ID="ID_696402753" MODIFIED="1354675233686" TEXT="&#x6253;&#x5f00;&#x8bf7;&#x6c42;&#x54cd;&#x5e94;&#x8c03;&#x8bd5;">
<node CREATED="1322703995223" ID="ID_350192575" MODIFIED="1354675233686" TEXT="&#x7f16;&#x8f91;urllib2&#x7684;do_open&#x91cc;&#x7684;h.set_debuglevel"/>
<node CREATED="1322704007581" ID="ID_1755125251" MODIFIED="1354675233686" TEXT="&#x6539;&#x4e3a;h.set_debuglevel(1)&#xff0c;&#x8fd9;&#x65f6;&#x53ef;&#x4ee5;&#x6e05;&#x6670;&#x770b;&#x5230;&#x8bf7;&#x6c42;&#x54cd;&#x5e94;&#x6570;&#x636e;&#xff0c;&#x5305;&#x62ec;https"/>
</node>
</node>
</node>
</node>
<node CREATED="1322705061812" ID="ID_810468983" MODIFIED="1322705066859" TEXT="&#x4ec0;&#x4e48;&#x662f;&#x8df3;&#x8f6c;">
<node CREATED="1322705067702" ID="ID_1774439873" MODIFIED="1354675513182" TEXT="&#x670d;&#x52a1;&#x7aef;&#x8df3;&#x8f6c;">
<node CREATED="1322705077972" ID="ID_975894827" MODIFIED="1322705079942" TEXT="302">
<node CREATED="1322705106827" ID="ID_1677769380" MODIFIED="1322705133294" TEXT="&lt;?php header(&quot;Location: 3.php&quot;); ?&gt; "/>
</node>
<node CREATED="1322705080166" ID="ID_293977056" MODIFIED="1322705081372" TEXT="301">
<node CREATED="1322705140008" ID="ID_259194197" MODIFIED="1322705145080" TEXT="&lt;?php header(&quot;HTTP/1.1 301 Moved Permanently&quot;); header(&quot;Location: 2.php&quot;); ?&gt; "/>
</node>
<node CREATED="1322705228866" ID="ID_1592941569" MODIFIED="1322708062227" TEXT="u=urllib2.urlopen(url)&#x540e;&#xff0c;u.url&#x80fd;&#x5f97;&#x5230;&#x670d;&#x52a1;&#x7aef;&#x8df3;&#x8f6c;&#x540e;&#x7684;&#x5730;&#x5740;">
<node CREATED="1322705255663" ID="ID_1001180128" MODIFIED="1322705260785" TEXT="urllib2&#x81ea;&#x5df1;&#x7684;&#x7279;&#x6027;"/>
<node CREATED="1322705261153" ID="ID_41374612" MODIFIED="1322705268617" TEXT="&#x6240;&#x8c13;&#x7684;&#x4f1a;&#x8ddf;&#x8fdb;&#x53bb;"/>
</node>
</node>
<node CREATED="1322705070592" ID="ID_1108934232" MODIFIED="1354675514995" TEXT="&#x5ba2;&#x6237;&#x7aef;&#x8df3;&#x8f6c;">
<node CREATED="1322705163045" ID="ID_1272724418" MODIFIED="1355475487949" STYLE="fork" TEXT="&lt;meta http-equiv=&quot;refresh&quot; content=&quot;0; url=http://www.evilcos.me&quot; /&gt;">
<node CREATED="1322705289101" ID="ID_670346646" MODIFIED="1355475486833" TEXT="htmlparse&#x89e3;&#x6790;&#x5c31;&#x884c;&#x4e86;"/>
</node>
<node CREATED="1322705183285" ID="ID_319459146" MODIFIED="1438757984306" TEXT="location.href=&quot;http:/&quot; + &quot;/evilcos.me&quot;;">
<node CREATED="1322705296718" ID="ID_1767323568" MODIFIED="1438757968891" TEXT="&#x6b63;&#x5219;&#x89e3;&#x6790;&#xff08;&#x5f31;&#xff09;"/>
<node CREATED="1438757937421" ID="ID_1141856300" MODIFIED="1438757959916" TEXT="JavaScript&#x5f15;&#x64ce;&#x89e3;&#x6790;&#xff08;&#x5f3a;&#xff09;"/>
</node>
</node>
</node>
<node CREATED="1355470570514" ID="ID_1308296693" MODIFIED="1355470748707" TEXT="Office&#x80fd;&#x529b;">
<node CREATED="1355470576557" ID="ID_1459111677" MODIFIED="1355470753432" TEXT="Word&#x6587;&#x6863;&#x7f16;&#x5199;&#xff0c;&#x770b;&#x53bb;&#x8981;&#x4e13;&#x4e1a;&#xff0c;&#x5c24;&#x5176;&#x5bf9;&#x5916;&#x7684;"/>
<node CREATED="1355470605716" ID="ID_1386651052" MODIFIED="1355470757344" TEXT="Excel&#x91cc;&#x9762;&#x5927;&#x91cf;&#x7684;&#x7edf;&#x8ba1;&#x3001;&#x56fe;&#x8868;&#x529f;&#x80fd;&#xff0c;&#x9700;&#x8981;&#x5584;&#x4e8e;&#x4f7f;&#x7528;"/>
<node CREATED="1355470722132" ID="ID_1060039220" MODIFIED="1438758627399" TEXT="PPT&#x6f14;&#x8bb2;&#x3001;&#x57f9;&#x8bad;&#x7b49;&#x5fc5;&#x5907;&#xff0c;&#x5982;&#x4f55;&#x505a;&#x597d;PPT&#xff1f;&#x767e;&#x5ea6;&#x4e00;&#x4e0b;..."/>
<node CREATED="1356083976914" ID="ID_1874673729" MODIFIED="1356083997031" TEXT="&#x8fdb;&#x4e00;&#x6b65;">
<icon BUILTIN="ksmiletris"/>
<node CREATED="1356083981725" ID="ID_932079806" MODIFIED="1394121335332" TEXT="yEd"/>
<node CREATED="1356083984338" ID="ID_36899514" MODIFIED="1394121338614" TEXT="Visio"/>
<node CREATED="1356083986811" ID="ID_363369584" MODIFIED="1394121344274" TEXT="FreeMind">
<node CREATED="1394121363040" ID="ID_1631895846" MODIFIED="1394121381923" TEXT=" &#x672c;&#x6280;&#x80fd;&#x8868;&#x5c31;&#x662f;&#x8fd9;&#x4e2a;&#x5236;&#x4f5c;"/>
</node>
</node>
</node>
<node CREATED="1438760440212" ID="ID_1961618991" MODIFIED="1438760448787" TEXT="&#x4e0a;&#x624b;Linux">
<node CREATED="1438769186673" ID="ID_49245443" MODIFIED="1438769328020" TEXT="&#x300a;&#x9e1f;&#x54e5;&#x7684;Linux&#x79c1;&#x623f;&#x83dc;&#x300b;"/>
</node>
<node CREATED="1355475531060" ID="ID_1591535633" MODIFIED="1355475539393" TEXT="&#x719f;&#x7ec3;VIM">
<node CREATED="1355475594310" ID="ID_928346823" LINK="http://coolshell.cn/articles/5426.html" MODIFIED="1394165833369" TEXT="&#x5b9e;&#x6218;&#x81f3;&#x5c11;3&#x56de;&#x5408;&#xff1a;http://coolshell.cn/articles/5426.html"/>
</node>
<node CREATED="1354674739023" ID="ID_98018794" MODIFIED="1438769297173" TEXT="&#x4e0a;&#x624b;Python">
<node CREATED="1439027923254" ID="ID_1924177318" LINK="https://www.python.org/dev/peps/pep-0008/" MODIFIED="1439027945783" TEXT="https://www.python.org/dev/peps/pep-0008/">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1438759278354" ID="ID_1487074517" LINK="http://learnpythonthehardway.org/book/" MODIFIED="1438759417368" TEXT="http://learnpythonthehardway.org/book/">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1354455686307" ID="ID_644873015" MODIFIED="1438769342426" TEXT="&#x300a;Python&#x6838;&#x5fc3;&#x7f16;&#x7a0b;2&#x300b;">
<node CREATED="1354455692091" ID="ID_1758750474" MODIFIED="1357466329781" TEXT="&#x7b2c;4&#x7ae0; Python&#x5bf9;&#x8c61;">
<node CREATED="1354519904382" ID="ID_1704097544" MODIFIED="1357466329781" TEXT="&#x5b8c;&#x6574;&#x719f;&#x7ec3;"/>
</node>
<node CREATED="1354519955081" ID="ID_693903230" MODIFIED="1357466329781" TEXT="6.8 Unicode">
<node CREATED="1354519970743" ID="ID_216755987" MODIFIED="1357466329781" TEXT="&#x5b8c;&#x6574;&#x719f;&#x7ec3;"/>
</node>
<node CREATED="1354520017998" ID="ID_49720039" MODIFIED="1357466329781" TEXT="8.11 &#x8fed;&#x4ee3;&#x5668;&#x548c;iter()&#x51fd;&#x6570;">
<node CREATED="1354520047838" ID="ID_1438731528" MODIFIED="1357466329781" TEXT="&#x5b8c;&#x6574;&#x719f;&#x7ec3;"/>
</node>
<node CREATED="1354520063907" ID="ID_1432039151" MODIFIED="1357466329782" TEXT="&#x7b2c;9&#x7ae0; &#x6587;&#x4ef6;&#x7684;&#x8f93;&#x5165;&#x548c;&#x8f93;&#x51fa;">
<node CREATED="1354520075310" ID="ID_729897487" MODIFIED="1357466329782" TEXT="&#x5b8c;&#x6574;&#x719f;&#x7ec3;"/>
</node>
<node CREATED="1354520093094" ID="ID_1446945199" MODIFIED="1357466329782" TEXT="&#x7b2c;10&#x7ae0; &#x9519;&#x8bef;&#x548c;&#x5f02;&#x5e38;">
<node CREATED="1354520100137" ID="ID_1080708444" MODIFIED="1357466329782" TEXT="&#x5b8c;&#x6574;&#x719f;&#x7ec3;"/>
</node>
<node CREATED="1354520147932" ID="ID_230918842" MODIFIED="1357466329782" TEXT="&#x7b2c;11&#x7ae0; &#x51fd;&#x6570;&#x548c;&#x51fd;&#x6570;&#x5f0f;&#x7f16;&#x7a0b;">
<node CREATED="1354520155476" ID="ID_423399835" MODIFIED="1357466329782" TEXT="&#x5b8c;&#x6574;&#x719f;&#x7ec3;"/>
</node>
<node CREATED="1354520178760" ID="ID_1862213683" MODIFIED="1357466329783" TEXT="&#x7b2c;12&#x7ae0; &#x6a21;&#x5757;">
<node CREATED="1354520184421" ID="ID_901547756" MODIFIED="1357466329783" TEXT="&#x5b8c;&#x6574;&#x719f;&#x7ec3;"/>
</node>
<node CREATED="1354520243683" ID="ID_1579442001" MODIFIED="1357466329783" TEXT="&#x7b2c;14&#x7ae0; &#x6267;&#x884c;&#x73af;&#x5883;">
<node CREATED="1354520251440" ID="ID_595819616" MODIFIED="1357466329783" TEXT="&#x5b8c;&#x6574;&#x719f;&#x7ec3;"/>
</node>
<node CREATED="1354520268335" ID="ID_1516575354" MODIFIED="1357466329783" TEXT="&#x7b2c;15&#x7ae0; &#x6b63;&#x5219;&#x8868;&#x8fbe;&#x5f0f;">
<node CREATED="1354520277216" ID="ID_1339274712" MODIFIED="1357466329784" TEXT="&#x5b8c;&#x6574;&#x719f;&#x7ec3;">
<icon BUILTIN="idea"/>
</node>
</node>
<node CREATED="1354520324285" ID="ID_1558707510" MODIFIED="1357466329784" TEXT="&#x7b2c;18&#x7ae0; &#x591a;&#x7ebf;&#x7a0b;&#x7f16;&#x7a0b;">
<node CREATED="1354520331048" ID="ID_1094125561" MODIFIED="1357466329784" TEXT="&#x5b8c;&#x6574;&#x719f;&#x7ec3;"/>
</node>
<node CREATED="1354520387716" ID="ID_222244046" MODIFIED="1357466329784" TEXT="20.2 &#x4f7f;&#x7528;Python&#x8fdb;&#x884c;Web&#x5e94;&#x7528;&#xff1a;&#x521b;&#x5efa;&#x4e00;&#x4e2a;&#x7b80;&#x5355;&#x7684;Web&#x5ba2;&#x6237;&#x7aef;">
<node CREATED="1354520416949" ID="ID_1881143874" MODIFIED="1357466329784" TEXT="&#x5b8c;&#x6574;&#x719f;&#x7ec3;"/>
</node>
</node>
</node>
<node CREATED="1354675458669" ID="ID_1674729959" MODIFIED="1354675463338" TEXT="&#x7b97;&#x6cd5;">
<node CREATED="1354675463836" ID="ID_899752274" MODIFIED="1354675465867" TEXT="&#x5feb;&#x6392;"/>
<node CREATED="1354675466055" ID="ID_403551998" MODIFIED="1354675467368" TEXT="&#x4e8c;&#x5206;"/>
</node>
<node CREATED="1355814339168" ID="ID_604257877" MODIFIED="1438757257503" TEXT="&#x6b63;&#x5219;&#x8868;&#x8fbe;&#x5f0f;">
<node CREATED="1355814347434" ID="ID_131326470" MODIFIED="1355815018495" TEXT="&#x8c03;&#x8bd5;&#x5de5;&#x5177;">
<node CREATED="1355815018934" ID="ID_1818882692" MODIFIED="1355815287958" TEXT="Kodos">
<icon BUILTIN="ksmiletris"/>
</node>
<node CREATED="1355815020149" ID="ID_1362170972" MODIFIED="1356671254157" TEXT="RegexBuddy">
<icon BUILTIN="idea"/>
<node CREATED="1356671260146" ID="ID_165074641" MODIFIED="1356671265283" TEXT="&#x652f;&#x6301;&#x591a;&#x79cd;&#x8bed;&#x8a00;"/>
<node CREATED="1356671266007" ID="ID_28179481" MODIFIED="1356671272093" TEXT="&#x652f;&#x6301;&#x8c03;&#x8bd5;&#x4f18;&#x5316;"/>
</node>
<node CREATED="1357447108542" ID="ID_1737335147" LINK="http://www.regexper.com/" MODIFIED="1394165283951" TEXT="http://www.regexper.com/">
<icon BUILTIN="ksmiletris"/>
<node CREATED="1357447112011" ID="ID_1001088554" MODIFIED="1357447127468" TEXT="&#x6b63;&#x5219;&#x56fe;&#x89e3;"/>
</node>
</node>
<node CREATED="1366962547543" ID="ID_523956780" LINK="http://deerchao.net/tutorials/regex/regex.htm" MODIFIED="1394165272640" TEXT="&#x6b63;&#x5219;&#x8868;&#x8fbe;&#x5f0f;30&#x5206;&#x949f;&#x5165;&#x95e8;&#x6559;&#x7a0b;&#xff1a;http://deerchao.net/tutorials/regex/regex.htm"/>
<node CREATED="1355994572034" ID="ID_1978070873" LINK="http://wiki.ubuntu.org.cn/Python&#x6b63;&#x5219;&#x8868;&#x8fbe;&#x5f0f;&#x64cd;&#x4f5c;&#x6307;&#x5357;" MODIFIED="1394165231186" TEXT="http://wiki.ubuntu.org.cn/Python&#x6b63;&#x5219;&#x8868;&#x8fbe;&#x5f0f;&#x64cd;&#x4f5c;&#x6307;&#x5357;"/>
<node CREATED="1439031774420" ID="ID_1263463606" MODIFIED="1439031780062" TEXT="&#x300a;&#x7cbe;&#x901a;&#x6b63;&#x5219;&#x8868;&#x8fbe;&#x5f0f;&#x300b;"/>
</node>
<node CREATED="1356671315573" ID="ID_156156916" MODIFIED="1438757275933" TEXT="&#x7814;&#x53d1;&#x80fd;&#x529b;">
<node CREATED="1356671319920" ID="ID_1727863322" MODIFIED="1356671323979" TEXT="&#x7011;&#x5e03;&#x6a21;&#x578b;">
<node CREATED="1356671329854" ID="ID_303622149" MODIFIED="1356671355324" TEXT="&#x9700;&#x6c42;-&gt;&#x9700;&#x6c42;&#x5206;&#x6790;-&gt;&#x8bbe;&#x8ba1;-&gt;&#x5f00;&#x53d1;-&gt;&#x6d4b;&#x8bd5;-&gt;&#x4e0a;&#x7ebf;-&gt;&#x8fd0;&#x7ef4;/&#x8fd0;&#x8425;"/>
</node>
<node CREATED="1357466111808" ID="ID_1119828073" MODIFIED="1394341624852" TEXT="&#x9700;&#x6c42;&#x5206;&#x6790;&#x80fd;&#x529b;">
<icon BUILTIN="idea"/>
<node CREATED="1357466116376" ID="ID_965089165" MODIFIED="1394121452120" TEXT="&#x7ed9;&#x4f60;&#x4e00;&#x4e2a;&#x9700;&#x6c42;&#xff0c;&#x5982;&#x4f55;&#x7ed9;&#x51fa;&#x4e00;&#x4e2a;&#x4f18;&#x7f8e;&#x7684;&#x6267;&#x884c;&#x601d;&#x8def;&#x2014;&#x2014;&#x65b9;&#x6cd5;&#x8bba;"/>
<node CREATED="1357466166056" ID="ID_677846063" MODIFIED="1357466173466" TEXT="&#x8fd9;&#x4e2a;&#x80fd;&#x529b;&#x975e;&#x5e38;&#x975e;&#x5e38;&#x975e;&#x5e38;&#x7684;&#x5173;&#x952e;"/>
</node>
<node CREATED="1366587536243" ID="ID_1215597968" MODIFIED="1366587541938" TEXT="&#x8c03;&#x8bd5;&#x80fd;&#x529b;">
<node CREATED="1366587544259" ID="ID_755333261" MODIFIED="1366588112903" TEXT="&#x53ea;&#x8981;&#x5b9a;&#x4f4d;&#x51fa;&#xff0c;&#x5c31;&#x6ca1;&#x6709;&#x89e3;&#x51b3;&#x4e0d;&#x4e86;&#x7684;Bugs"/>
<node CREATED="1322707936987" ID="ID_381171729" MODIFIED="1322729470347" TEXT="&#x8089;&#x773c;&#x770b;&#x5230;&#x7684;&#x90fd;&#x662f;&#x5047;&#x8c61;">
<node CREATED="1322707949055" ID="ID_1211464378" MODIFIED="1322729814946" TEXT="&#x4e00;&#x5b9a;&#x8981;&#x4e13;&#x4e1a;&#x7684;&#x5de5;&#x5177;&#x4e0e;&#x7ecf;&#x9a8c;&#x914d;&#x5408;"/>
</node>
<node CREATED="1366587704258" ID="ID_378549260" MODIFIED="1366587775412" TEXT="Bugs&#x5728;&#x54ea;&#x51fa;&#x73b0;&#xff0c;&#x6700;&#x7ec8;&#x5c31;&#x5728;&#x54ea;&#x8fdb;&#x884c;&#x771f;&#x5b9e;&#x6a21;&#x62df;&#x8c03;&#x8bd5;"/>
<node CREATED="1322704156447" ID="ID_158280602" MODIFIED="1366587388420" TEXT="&#x7f29;&#x5c0f;&#x8303;&#x56f4;">
<node CREATED="1322704167499" ID="ID_737342372" MODIFIED="1322704175295" TEXT="&#x6784;&#x5efa;&#x81ea;&#x5df1;&#x7684;&#x6d4b;&#x8bd5;&#x6837;&#x4f8b;">
<node CREATED="1322704175907" ID="ID_989520069" MODIFIED="1322704187749" TEXT="&#x6392;&#x9664;&#x7f51;&#x7edc;&#x590d;&#x6742;&#x672a;&#x77e5;&#x60c5;&#x51b5;"/>
</node>
<node CREATED="1322704189149" ID="ID_1862534563" MODIFIED="1322704250988" TEXT="&#x5173;&#x8054;&#x6a21;&#x5757;&#x4e00;&#x4e2a;&#x4e2a;&#x6392;&#x9664;"/>
<node CREATED="1322704093343" ID="ID_1259318333" MODIFIED="1366587734996" TEXT="Python&#x5355;&#x6b65;&#x8c03;&#x8bd5;">
<node CREATED="1322704076871" ID="ID_1873855548" MODIFIED="1322704086705" TEXT="import pdb;pdb.set_trace()"/>
<node CREATED="1322704105535" ID="ID_1501288120" MODIFIED="1322704147210" TEXT="&#x5728;&#x9700;&#x8981;&#x5355;&#x6b65;&#x8c03;&#x8bd5;&#x7684;&#x5730;&#x65b9;&#x52a0;&#x4e0a;&#x9762;&#x8fd9;&#x53e5;&#xff0c;&#x8fd0;&#x884c;&#x7a0b;&#x5e8f;&#x540e;&#x4e2d;&#x65ad;&#x5728;&#x6b64;&#xff0c;&#x7136;&#x540e;h&#x67e5;&#x770b;&#x6307;&#x4ee4;&#x8fdb;&#x884c;&#x4e00;&#x6b65;&#x6b65;&#x7ec6;&#x7ec6;&#x8c03;&#x8bd5;"/>
</node>
<node CREATED="1366587668615" ID="ID_335126999" MODIFIED="1366587676081" TEXT="&#x7c97;&#x66b4;&#x8c03;&#x8bd5;&#xff1a;print"/>
</node>
</node>
<node CREATED="1356671324167" ID="ID_1254504031" MODIFIED="1356671327333" TEXT="&#x654f;&#x6377;&#x601d;&#x60f3;">
<node CREATED="1356671358905" ID="ID_1159002270" MODIFIED="1356671363653" TEXT="&#x5feb;&#x901f;&#x8fed;&#x4ee3;"/>
<node CREATED="1356671363867" ID="ID_1077402264" MODIFIED="1356671368674" TEXT="&#x4efb;&#x52a1;&#x62c6;&#x7ec6;"/>
<node CREATED="1356671368800" ID="ID_1666863364" MODIFIED="1438757300196" TEXT="v1&#x539f;&#x5219;&#xff1a;&#x5b9a;&#x4e49;&#x597d;v1&#x7684;&#x76ee;&#x6807;&#xff0c;&#x5feb;&#x901f;&#x5b8c;&#x6210;v1&#x4e3a;&#x4f18;&#x5148;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1356671771630" ID="ID_1997837839" MODIFIED="1394121492655" TEXT="&#x4e60;&#x60ef;Wiki&#x8bb0;&#x5f55;&#xff0c;&#x5229;&#x4e8e;&#x6c89;&#x6dc0;&#x4e0e;&#x5206;&#x4eab;"/>
</node>
</node>
<node CREATED="1354689973031" ID="ID_1307512017" MODIFIED="1438757304807" TEXT="&#x7ffb;&#x5899;">
<node CREATED="1438757635170" ID="ID_1619844582" MODIFIED="1438757642745" TEXT="&#x4f18;&#x96c5;&#x89e3;&#x51b3;&#x65b9;&#x6848;">
<node CREATED="1438757647721" ID="ID_877060944" MODIFIED="1438757809281" TEXT="shadowsocks + &#x4e00;&#x53f0;&#x6d77;&#x5916; VPS + Chrome(SwitchyOmega)/Firefox(AutoProxy)"/>
<node CREATED="1438757835783" ID="ID_1911057780" LINK="http://mp.weixin.qq.com/s?__biz=MzA3NTEzMTUwNA==&amp;mid=210457700&amp;idx=1&amp;sn=322d1e4c13d3f33ade848e3889c410bf#rd" MODIFIED="1438757893393" TEXT="&#x8be6;&#x60c5;&#x4e86;&#x89e3;&#xff1a;http://mp.weixin.qq.com/s?__biz=MzA3NTEzMTUwNA==&amp;mid=210457700&amp;idx=1&amp;sn=322d1e4c13d3f33ade848e3889c410bf#rd"/>
</node>
<node CREATED="1354689977570" ID="ID_727329030" MODIFIED="1354689983048" TEXT="SSH&#x96a7;&#x9053;">
<node CREATED="1354693380596" ID="ID_1395932476" LINK="http://www.ibm.com/developerworks/cn/linux/l-cn-sshforward/index.html" MODIFIED="1394165217764" TEXT="http://www.ibm.com/developerworks/cn/linux/l-cn-sshforward/index.html"/>
<node CREATED="1354693383449" ID="ID_1249224034" MODIFIED="1354693385779" TEXT="&#x672c;&#x5730;&#x8f6c;&#x53d1;">
<node CREATED="1354693408721" ID="ID_627117691" MODIFIED="1354693409742" TEXT="ssh -L &lt;local port&gt;:&lt;remote host&gt;:&lt;remote port&gt; &lt;SSH hostname&gt;"/>
</node>
<node CREATED="1354693385972" ID="ID_158190281" MODIFIED="1354693388357" TEXT="&#x8fdc;&#x7a0b;&#x8f6c;&#x53d1;">
<node CREATED="1354693431097" ID="ID_363182493" MODIFIED="1354693433095" TEXT="&#x53cd;&#x5f39;"/>
<node CREATED="1354693433249" ID="ID_730970927" MODIFIED="1354693434277" TEXT="ssh -R &lt;local port&gt;:&lt;remote host&gt;:&lt;remote port&gt; &lt;SSH hostname&gt;"/>
</node>
<node CREATED="1354693388541" ID="ID_1319876310" MODIFIED="1354693391292" TEXT="&#x52a8;&#x6001;&#x8f6c;&#x53d1;">
<node CREATED="1354693457263" ID="ID_369348260" MODIFIED="1354693457983" TEXT="ssh -D &lt;local port&gt; &lt;SSH Server&gt;"/>
</node>
</node>
</node>
</node>
<node CREATED="1354455673045" ID="ID_6348845" MODIFIED="1438935995909" TEXT="Web&#x5b89;&#x5168;">
<node CREATED="1395154471846" ID="ID_847446733" MODIFIED="1395154501891" TEXT="&#x96f6;&#x57fa;&#x7840;&#x5982;&#x4f55;&#x5b66;&#x4e60;Web&#x5b89;&#x5168;">
<node CREATED="1395154490143" ID="ID_1871381727" LINK="http://www.zhihu.com/question/21606800/answer/22268855" MODIFIED="1395154517789" TEXT="http://www.zhihu.com/question/21606800/answer/22268855"/>
</node>
<node CREATED="1376276952380" ID="ID_648962906" MODIFIED="1376277846814" TEXT="Web&#x670d;&#x52a1;&#x7ec4;&#x4ef6;">
<node CREATED="1376277848515" ID="ID_348776388" LINK="res/web_component.png" MODIFIED="1439032100208" TEXT="8+1&#xff1a;&#x4e00;&#x56fe;&#x80dc;&#x5343;&#x8a00;&#x54ce;:)"/>
<node CREATED="1376277868649" ID="ID_864491569" MODIFIED="1376277934896" TEXT="&#x949f;&#x9997;&#x4e4b;&#x773c;">
<node CREATED="1376277880532" ID="ID_500917528" MODIFIED="1376278128568" TEXT="&#x7f51;&#x7edc;&#x7a7a;&#x95f4;&#x641c;&#x7d22;&#x5f15;&#x64ce;"/>
<node CREATED="1376277925612" ID="ID_185595992" LINK="http://www.zoomeye.org" MODIFIED="1438770456781" TEXT="http://zoomeye.org"/>
<node CREATED="1439028111041" ID="ID_1627773054" LINK="http://www.zoomeye.org/search/dork" MODIFIED="1439028151355" TEXT="&#x5927;&#x91cf;&#x6837;&#x4f8b;&#xff1a;http://www.zoomeye.org/search/dork"/>
</node>
<node CREATED="1376278142211" ID="ID_1563011822" MODIFIED="1376278160867" TEXT="&#x7ec4;&#x4ef6;&#x5177;&#x6709;&#x5f71;&#x54cd;&#x9762;&#xff0c;&#x8d8a;&#x5e95;&#x5c42;&#x7684;&#x7ec4;&#x4ef6;&#x5f71;&#x54cd;&#x9762;&#x53ef;&#x80fd;&#x8d8a;&#x5927;"/>
</node>
<node CREATED="1337084905445" ID="ID_1079956129" MODIFIED="1357466329791" TEXT="&#x5b89;&#x5168;&#x7ef4;&#x5ea6;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1337084910202" ID="ID_1874035764" MODIFIED="1357466329791" TEXT="&#x6f0f;&#x6d1e;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1337084915001" ID="ID_497478891" MODIFIED="1357466329792" TEXT="&#x98ce;&#x9669;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1337084912729" ID="ID_1838655135" MODIFIED="1357466329792" TEXT="&#x4e8b;&#x4ef6;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1366587923607" ID="ID_1918211808" MODIFIED="1366587928132" TEXT="Web&#x5b89;&#x5168;&#x6807;&#x51c6;">
<node CREATED="1366587928794" ID="ID_1765698050" MODIFIED="1366587930984" TEXT="OWASP"/>
<node CREATED="1366587931229" ID="ID_1614164343" MODIFIED="1366587935740" TEXT="WASC"/>
</node>
<node CREATED="1354694694213" ID="ID_1732320514" MODIFIED="1357466329792" TEXT="&#x5b9e;&#x6218;&#x73af;&#x5883;">
<node CREATED="1355802349490" ID="ID_539143606" MODIFIED="1357466329792" TEXT="XSS">
<node CREATED="1354694701920" ID="ID_203570538" MODIFIED="1438940505308" TEXT="&#x5185;&#x90e8;&#x5e73;&#x53f0;&#xff1a;ks-xsslab_open">
<node CREATED="1354694733419" ID="ID_524159683" MODIFIED="1438940521005" TEXT="&#x53ef;&#x4ee5;&#x4e0a;&#x624b;">
<node CREATED="1354694764348" ID="ID_581580993" MODIFIED="1357466329793" TEXT="XSS"/>
<node CREATED="1354694765971" ID="ID_1340113167" MODIFIED="1357466329793" TEXT="CSRF"/>
<node CREATED="1354694767880" ID="ID_600518274" MODIFIED="1357466329793" TEXT="ClickJacking"/>
</node>
</node>
<node CREATED="1355802357828" ID="ID_1066519588" LINK="http://xss-quiz.int21h.jp/" MODIFIED="1438402903784" TEXT="http://xss-quiz.int21h.jp/">
<node CREATED="1355802697727" ID="ID_131295260" LINK="res/xss_quiz.txt" MODIFIED="1439032082834" TEXT="&#x7b54;&#x6848;&#xff1a;xss_quiz.txt">
<icon BUILTIN="attach"/>
</node>
</node>
<node COLOR="#000000" CREATED="1438402904501" ID="ID_250204955" LINK="http://prompt.ml/0" MODIFIED="1438770010994" TEXT="http://prompt.ml/0">
<node COLOR="#000000" CREATED="1438402927222" ID="ID_1802970635" LINK="https://github.com/cure53/XSSChallengeWiki/wiki/prompt.ml" MODIFIED="1438770011005" TEXT="&#x7b54;&#x6848;&#xff1a;https://github.com/cure53/XSSChallengeWiki/wiki/prompt.ml"/>
</node>
<node COLOR="#000000" CREATED="1438403056993" ID="ID_881415276" LINK="http://escape.alf.nu/" MODIFIED="1438770011001" TEXT="http://escape.alf.nu/">
<node COLOR="#000000" CREATED="1438403068056" ID="ID_1343783184" LINK="http://blog.nsfocus.net/alert1-to-win-write-up/" MODIFIED="1438770011004" TEXT="&#x7b54;&#x6848;&#xff1a;http://blog.nsfocus.net/alert1-to-win-write-up/"/>
</node>
</node>
<node CREATED="1355802352357" ID="ID_1577025587" MODIFIED="1357466329794" TEXT="SQL">
<node CREATED="1355802362230" ID="ID_478970715" LINK="https://github.com/Audi-1/sqli-labs" MODIFIED="1394165184498" TEXT="https://github.com/Audi-1/sqli-labs">
<node CREATED="1355802798781" ID="ID_75529022" MODIFIED="1357466329794" TEXT="SQLI-LABS is a platform to learn SQLI"/>
</node>
</node>
<node CREATED="1438770240841" ID="ID_1552152798" MODIFIED="1438770248181" TEXT="i&#x6625;&#x79cb;">
<node CREATED="1438770250351" ID="ID_347352281" LINK="http://www.ichunqiu.com/" MODIFIED="1438770257913" TEXT="http://www.ichunqiu.com/"/>
</node>
<node CREATED="1354694706206" ID="ID_635030401" MODIFIED="1463561955223" TEXT="Seebug + ZoomEye">
<node CREATED="1438770082190" ID="ID_1023804165" LINK="http://seebug.org" MODIFIED="1463562002786" TEXT="http://seebug.org"/>
<node CREATED="1438770086630" ID="ID_730583595" LINK="http://zoomeye.org" MODIFIED="1438770127727" TEXT="http://zoomeye.org"/>
<node CREATED="1438770479978" ID="ID_993454021" MODIFIED="1438770486791" TEXT="&#x4f60;&#x61c2;&#x5f97;..."/>
</node>
</node>
<node CREATED="1438937126235" ID="ID_411497739" MODIFIED="1438937129643" TEXT="&#x5de5;&#x5177;">
<node CREATED="1438937158670" ID="ID_667119282" MODIFIED="1438937299071" TEXT="&#x6211;&#x7684;&#x6e17;&#x900f;&#x5229;&#x5668;">
<node CREATED="1438937700608" ID="ID_1997038129" MODIFIED="1438937705645" TEXT="Firefox">
<node CREATED="1354673790435" ID="ID_942290943" MODIFIED="1394121167611" TEXT="Firebug">
<node CREATED="1354673858675" ID="ID_496838908" MODIFIED="1438938203150" TEXT="&#x8c03;&#x8bd5;JavaScript&#xff0c;HTTP&#x8bf7;&#x6c42;&#x54cd;&#x5e94;&#x89c2;&#x5bdf;&#xff0c;Cookie&#xff0c;DOM&#x6811;&#x89c2;&#x5bdf;&#x7b49;"/>
</node>
<node CREATED="1354673796286" ID="ID_982838006" MODIFIED="1394121222701" TEXT="Tamper Data">
<node CREATED="1354673853994" ID="ID_1032911378" MODIFIED="1354675233676" TEXT="&#x62e6;&#x622a;&#x4fee;&#x6539;"/>
</node>
<node CREATED="1354673799927" ID="ID_1487742016" MODIFIED="1394121232394" TEXT="Live Http Header">
<node CREATED="1354673842654" ID="ID_1490604592" MODIFIED="1354675233676" TEXT="&#x91cd;&#x653e;&#x529f;&#x80fd;"/>
</node>
<node CREATED="1354673870639" ID="ID_516507007" MODIFIED="1394121238226" TEXT="Hackbar">
<node CREATED="1354673876882" ID="ID_1468250395" MODIFIED="1354675233676" TEXT="&#x7f16;&#x7801;&#x89e3;&#x7801;/POST&#x63d0;&#x4ea4;"/>
</node>
<node CREATED="1354674135293" ID="ID_72399270" MODIFIED="1394121247289" TEXT="Modify Headers">
<node CREATED="1354674150520" ID="ID_1082426970" MODIFIED="1354675233676" TEXT="&#x4fee;&#x6539;&#x5934;&#x90e8;"/>
</node>
<node CREATED="1438937836109" ID="ID_406537260" MODIFIED="1438937836770" TEXT="GreaseMonkey">
<node CREATED="1438937848868" ID="ID_1616378169" LINK="http://userscripts.org/scripts/show/119798" MODIFIED="1438938162626" TEXT="Original Cookie Injector for Greasemonkey"/>
</node>
<node CREATED="1438937929084" ID="ID_891160750" MODIFIED="1438937931351" TEXT="NoScript">
<node CREATED="1438937938456" ID="ID_43219861" MODIFIED="1438937945011" TEXT="&#x8fdb;&#x884c;&#x4e00;&#x4e9b;JavaScript&#x7684;&#x963b;&#x65ad;"/>
</node>
<node CREATED="1438938247996" ID="ID_568432686" MODIFIED="1438938252561" TEXT="AutoProxy">
<node CREATED="1438938254394" ID="ID_386335557" MODIFIED="1438938256110" TEXT="&#x7ffb;&#x5899;&#x5fc5;&#x5907;"/>
</node>
</node>
<node CREATED="1438937705909" ID="ID_716700508" MODIFIED="1438937708156" TEXT="Chrome">
<node CREATED="1438938273100" ID="ID_259083674" MODIFIED="1438938275763" TEXT="F12">
<node CREATED="1438938288821" ID="ID_1453250927" MODIFIED="1438938290249" TEXT="&#x6253;&#x5f00;&#x5f00;&#x53d1;&#x8005;&#x5de5;&#x5177;&#xff0c;&#x529f;&#x80fd;==Firebug+&#x672c;&#x5730;&#x5b58;&#x50a8;&#x89c2;&#x5bdf;&#x7b49;"/>
</node>
<node CREATED="1438938297146" ID="ID_135882731" MODIFIED="1438938298075" TEXT="SwichySharp">
<node CREATED="1438938254394" ID="ID_145755656" MODIFIED="1438938256110" TEXT="&#x7ffb;&#x5899;&#x5fc5;&#x5907;"/>
</node>
<node CREATED="1438938414264" ID="ID_1402843301" MODIFIED="1438938442234" TEXT="CookieHacker">
<node CREATED="1438938422436" ID="ID_1267567507" LINK="http://evilcos.me/?p=366 " MODIFIED="1438938449144" TEXT="http://evilcos.me/?p=366"/>
</node>
</node>
<node CREATED="1438937708358" ID="ID_330190486" MODIFIED="1438937723780" TEXT="Web2.0 Hacking">
<node CREATED="1438938498781" ID="ID_280619834" MODIFIED="1438938514215" TEXT="XSS&apos;OR">
<node CREATED="1438938641091" ID="ID_942299217" MODIFIED="1438938641961" TEXT="&#x5e38;&#x7528;&#x5176;&#x4e2d;&#x52a0;&#x89e3;&#x5bc6;&#x4e0e;&#x4ee3;&#x7801;&#x751f;&#x6210;"/>
<node CREATED="1438938515953" ID="ID_1897024299" LINK="http://evilcos.me/lab/xssor/" MODIFIED="1438938520116" TEXT="http://evilcos.me/lab/xssor/"/>
<node CREATED="1438938527985" ID="ID_828865212" LINK="https://github.com/evilcos/xssor" MODIFIED="1438938536100" TEXT="&#x6e90;&#x7801;&#xff1a;https://github.com/evilcos/xssor"/>
</node>
<node CREATED="1438938573181" ID="ID_29280349" MODIFIED="1438938590554" TEXT="XSSEE 3.0 Beta">
<node CREATED="1438938628028" ID="ID_55910468" MODIFIED="1438938629167" TEXT="Monyer&#x5f00;&#x53d1;&#x7684;&#xff0c;&#x52a0;&#x89e3;&#x5bc6;&#x6700;&#x597d;&#x7528;&#x795e;&#x5668;"/>
<node CREATED="1438938661390" ID="ID_414011444" LINK="http://evilcos.me/lab/xssee/" MODIFIED="1438938664053" TEXT="http://evilcos.me/lab/xssee/"/>
</node>
<node CREATED="1438938686704" ID="ID_1520542799" MODIFIED="1438938687399" TEXT="Online JavaScript beautifier">
<node CREATED="1438938788790" ID="ID_1000999079" MODIFIED="1438938799038" TEXT="JavaScript&#x7f8e;&#x5316;&#x5de5;&#x5177;&#xff0c;&#x5206;&#x6790;JavaScript&#x5e38;&#x7528;"/>
<node CREATED="1438938713839" ID="ID_551612554" LINK="http://jsbeautifier.org/" MODIFIED="1438938726096" TEXT="http://jsbeautifier.org/"/>
</node>
<node CREATED="1438938910482" ID="ID_1366179255" MODIFIED="1438938913083" TEXT="BeEF">
<node CREATED="1438939035405" ID="ID_850448904" MODIFIED="1438939036068" TEXT="The Browser Exploitation Framework"/>
<node CREATED="1438938914909" ID="ID_909578663" LINK="http://beefproject.com/" MODIFIED="1438938919949" TEXT="http://beefproject.com/"/>
</node>
</node>
<node CREATED="1438939083187" ID="ID_898920069" MODIFIED="1438939090823" TEXT="HTTP&#x4ee3;&#x7406;">
<node CREATED="1438939098953" ID="ID_1275083414" MODIFIED="1438939102812" TEXT="Fiddler">
<node CREATED="1438939115327" ID="ID_1275470355" MODIFIED="1438939189796" TEXT="&#x975e;&#x5e38;&#x7ecf;&#x5178;&#x597d;&#x7528;&#x7684;Web&#x8c03;&#x8bd5;&#x4ee3;&#x7406;&#x5de5;&#x5177;"/>
</node>
<node CREATED="1438939204179" ID="ID_37158047" MODIFIED="1438939219380" TEXT="Burp Suite">
<node CREATED="1438939220654" ID="ID_1137729240" MODIFIED="1438939221554" TEXT="&#x795e;&#x5668;&#xff0c;&#x4e0d;&#x4ec5;HTTP&#x4ee3;&#x7406;&#xff0c;&#x8fd8;&#x6709;&#x722c;&#x866b;&#x3001;&#x6f0f;&#x6d1e;&#x626b;&#x63cf;&#x3001;&#x6e17;&#x900f;&#x3001;&#x7206;&#x7834;&#x7b49;&#x529f;&#x80fd;"/>
</node>
<node CREATED="1438939223531" ID="ID_464697077" MODIFIED="1438939261058" TEXT="mitmproxy">
<node CREATED="1438939271441" ID="ID_1441886368" MODIFIED="1438939302194" TEXT="Python&#x5199;&#x7684;&#xff0c;&#x57fa;&#x4e8e;&#x8fd9;&#x4e2a;&#x6846;&#x67b6;&#x5199;&#x795e;&#x5668;&#x5b9e;&#x5728;&#x592a;&#x65b9;&#x4fbf;&#x4e86;"/>
</node>
</node>
<node CREATED="1438939345639" ID="ID_884286095" MODIFIED="1438939348512" TEXT="&#x6f0f;&#x6d1e;&#x626b;&#x63cf;">
<node CREATED="1438939349812" ID="ID_838452637" MODIFIED="1438939360996" TEXT="AWVS">
<node CREATED="1438939362326" ID="ID_1160153549" MODIFIED="1438939363051" TEXT="&#x4e0d;&#x4ec5;&#x6f0f;&#x626b;&#x65b9;&#x4fbf;&#xff0c;&#x81ea;&#x5e26;&#x7684;&#x4e00;&#x4e9b;&#x5c0f;&#x5de5;&#x5177;&#x4e5f;&#x597d;&#x7528;"/>
</node>
<node CREATED="1438939378833" ID="ID_1626242057" MODIFIED="1438939383561" TEXT="Nmap">
<node CREATED="1438939384923" ID="ID_1583396115" MODIFIED="1438939385806" TEXT="&#x7edd;&#x5bf9;&#x4e0d;&#x4ec5;&#x4ec5;&#x662f;&#x7aef;&#x53e3;&#x626b;&#x63cf;&#xff01;&#x51e0;&#x767e;&#x4e2a;&#x811a;&#x672c;"/>
</node>
<node CREATED="1438939395854" ID="ID_426340864" MODIFIED="1438939401354" TEXT="Python&#x81ea;&#x5199;&#x811a;&#x672c;/&#x5de5;&#x5177;"/>
</node>
<node CREATED="1438939417590" ID="ID_881784032" MODIFIED="1438939422385" TEXT="&#x6f0f;&#x6d1e;&#x5229;&#x7528;">
<node CREATED="1438939424179" ID="ID_1775213801" MODIFIED="1438939427526" TEXT="sqlmap">
<node CREATED="1438939428646" ID="ID_1929723421" MODIFIED="1438939429796" TEXT="SQL&#x6ce8;&#x5165;&#x5229;&#x7528;&#x6700;&#x725b;&#x795e;&#x5668;&#xff0c;&#x6ca1;&#x6709;&#x4e4b;&#x4e00;"/>
</node>
<node CREATED="1438939441881" ID="ID_393956421" MODIFIED="1438939476721" TEXT="Metasploit">
<node CREATED="1438939477899" ID="ID_877906672" MODIFIED="1438939490635" TEXT="&#x6700;&#x7ecf;&#x5178;&#x7684;&#x6e17;&#x900f;&#x6846;&#x67b6;"/>
</node>
<node CREATED="1438939503539" ID="ID_554925463" MODIFIED="1438939505634" TEXT="Hydra">
<node CREATED="1438939507092" ID="ID_755657871" MODIFIED="1438939508176" TEXT="&#x7206;&#x7834;&#x5fc5;&#x5907;"/>
</node>
</node>
<node CREATED="1438939528631" ID="ID_1316644563" MODIFIED="1438939536693" TEXT="&#x6293;&#x5305;&#x5de5;&#x5177;">
<node CREATED="1438939541953" ID="ID_1713721766" MODIFIED="1438939548033" TEXT="Wireshark">
<node CREATED="1438939549267" ID="ID_1859286346" MODIFIED="1438939549853" TEXT="&#x6293;&#x5305;&#x5fc5;&#x5907;"/>
</node>
<node CREATED="1438939558934" ID="ID_1387806970" MODIFIED="1438939669189" TEXT="Tcpdump">
<node CREATED="1438939568846" ID="ID_582375631" MODIFIED="1438939569859" TEXT="Linux&#x4e0b;&#x547d;&#x4ee4;&#x884c;&#x6293;&#x5305;&#xff0c;&#x7ed3;&#x679c;&#x53ef;&#x4ee5;&#x7ed9;Wireshark&#x5206;&#x6790;"/>
</node>
</node>
<node CREATED="1354694706206" ID="ID_108146988" MODIFIED="1463562037134" TEXT="Seebug + ZoomEye">
<node CREATED="1438770479978" ID="ID_909871831" MODIFIED="1438939742697" TEXT="&#x7c7b;&#x4f3c;&#x8fd9;&#x7c7b;&#x5e73;&#x53f0;&#x90fd;&#x662f;&#x6211;&#x4eec;&#x9700;&#x8981;&#x7684;"/>
<node CREATED="1438940318555" ID="ID_19521148" MODIFIED="1463562041167" TEXT="Seebug&#x7c7b;&#x4f3c;&#x7684;">
<node CREATED="1438940343074" ID="ID_1284934621" MODIFIED="1438940344007" TEXT="https://www.exploit-db.com/"/>
</node>
<node CREATED="1438940352049" ID="ID_286056024" MODIFIED="1438940361732" TEXT="ZoomEye&#x7c7b;&#x4f3c;&#x7684;">
<node CREATED="1438940375111" ID="ID_992905474" MODIFIED="1438940376043" TEXT="https://www.shodan.io/"/>
</node>
</node>
</node>
<node CREATED="1354694779320" ID="ID_584453805" MODIFIED="1438939626929" TEXT="Kali Linux">
<node CREATED="1354694809449" ID="ID_1319404638" MODIFIED="1438939608008" TEXT="&#x9664;&#x4e86;&#x4e0a;&#x9762;&#x4ecb;&#x7ecd;&#x7684;&#x4e00;&#x4e9b;&#x5de5;&#x5177;&#xff0c;&#x5176;&#x4ed6;&#x6d77;&#x91cf;&#x5404;&#x7c7b;&#x578b;&#x9ed1;&#x5ba2;&#x5de5;&#x5177;&#xff0c;&#x81ea;&#x5df1;&#x53bb;&#x6478;&#x7d22;"/>
</node>
</node>
<node CREATED="1366588167873" ID="ID_1500663226" MODIFIED="1366588170412" TEXT="&#x4e66;">
<node CREATED="1366588371107" ID="ID_1536690177" MODIFIED="1438937076221" TEXT="&#x300a;&#x9ed1;&#x5ba2;&#x653b;&#x9632;&#x6280;&#x672f;&#x5b9d;&#x5178;&#xff08;Web&#x5b9e;&#x6218;&#x7bc7;&#xff09;&#x300b;"/>
<node CREATED="1366588191863" ID="ID_1433268427" MODIFIED="1438937080864" TEXT="&#x300a;&#x767d;&#x5e3d;&#x5b50;&#x8bb2;Web&#x5b89;&#x5168;&#x300b;"/>
<node CREATED="1366588205577" ID="ID_364330957" MODIFIED="1438937087011" TEXT="&#x300a;Web&#x524d;&#x7aef;&#x9ed1;&#x5ba2;&#x6280;&#x672f;&#x63ed;&#x79d8;&#x300b;">
<node CREATED="1394122006977" ID="ID_1271600566" MODIFIED="1438770366867" TEXT="&#x6211;&#x548c;xisigr&#x51fa;&#x54c1;"/>
</node>
<node COLOR="#000000" CREATED="1438403566726" ID="ID_1424116049" MODIFIED="1438937093238" TEXT="&#x300a;Web&#x4e4b;&#x56f0;&#x300b;"/>
<node CREATED="1366588419581" ID="ID_895396460" MODIFIED="1438937097376" TEXT="&#x300a;SQL&#x6ce8;&#x5165;&#x653b;&#x51fb;&#x4e0e;&#x9632;&#x5fa1;&#x300b;"/>
</node>
<node CREATED="1366588563087" ID="ID_621102341" MODIFIED="1366588566742" TEXT="papers">
<node CREATED="1366588567579" ID="ID_1052450482" LINK="http://www.exploit-db.com/papers/" MODIFIED="1394165147359" TEXT="http://www.exploit-db.com/papers/"/>
<node CREATED="1366588569129" ID="ID_996407579" MODIFIED="1438770423696" TEXT="BlackHat/Defcon/XCon/KCon/&#x56fd;&#x5185;&#x5404;&#x5b89;&#x5168;&#x6c99;&#x9f99;&#x7b49;&#x76f8;&#x5173;Papers&#x9700;&#x8981;&#x6301;&#x7eed;&#x8ddf;&#x8fdb;"/>
</node>
</node>
<node COLOR="#000000" CREATED="1438404748154" ID="ID_814036276" MODIFIED="1438932620551" TEXT="&#x5d4c;&#x5165;&#x5f0f;&#x5b89;&#x5168;">
<icon BUILTIN="idea"/>
<node CREATED="1438404808194" ID="ID_1760752724" MODIFIED="1438404811867" TEXT="&#x8def;&#x7531;&#x5668;&#x5b89;&#x5168;">
<node CREATED="1438591171066" ID="ID_1539910688" MODIFIED="1438781779791" TEXT="&#x57fa;&#x7840;">
<node CREATED="1438591191672" ID="ID_196034468" MODIFIED="1438929708453" TEXT="&#x5d4c;&#x5165;&#x5f0f;Linux&#x7cfb;&#x7edf;&#x65b9;&#x9762;&#x77e5;&#x8bc6;"/>
<node CREATED="1438929815468" ID="ID_625554257" MODIFIED="1463562057422" TEXT="&#x5f00;&#x653e;&#x7cfb;&#x7edf;&#x4e92;&#x8054;&#x53c2;&#x8003;&#x6a21;&#x578b;-&#x7b2c;&#x4e09;&#x5c42;&#x7f51;&#x7edc;&#x5c42;"/>
<node CREATED="1438591206961" ID="ID_1311465057" MODIFIED="1438781817988" TEXT="MIPS/ARM&#x6c47;&#x7f16;&#x77e5;&#x8bc6;"/>
<node CREATED="1438932642361" ID="ID_1941694186" MODIFIED="1438932701157" TEXT="VxWorks&#x7cfb;&#x7edf;&#x65b9;&#x9762;&#x77e5;&#x8bc6;"/>
<node CREATED="1438932888743" ID="ID_727891663" MODIFIED="1438932896168" TEXT="JTAG&#x8c03;&#x8bd5;&#x63a5;&#x53e3;&#x89c4;&#x8303;"/>
<node CREATED="1438930159640" ID="ID_1659134652" MODIFIED="1438930185656" TEXT="&#x5d4c;&#x5165;&#x5f0f;&#x7cfb;&#x7edf;&#x4ea4;&#x53c9;&#x73af;&#x5883;&#x5f00;&#x53d1;"/>
<node CREATED="1438930043468" ID="ID_1166647204" MODIFIED="1438930212328" TEXT="&#x8def;&#x7531;&#x5668;&#x82af;&#x7247;&#x65b9;&#x6848;&#x63d0;&#x4f9b;&#x5546;">
<node CREATED="1438930062734" ID="ID_240288924" MODIFIED="1438930082843" TEXT="&#x535a;&#x901a;"/>
<node CREATED="1438930216312" ID="ID_1225303744" MODIFIED="1438930238296" TEXT="Atheros"/>
<node CREATED="1438930246187" ID="ID_1787930999" MODIFIED="1438905976918" TEXT="TrendChip"/>
<node CREATED="1438930279218" ID="ID_139543423" MODIFIED="1438930298421" TEXT="ACROSPEED"/>
<node CREATED="1438930332187" ID="ID_800818365" MODIFIED="1438930336890" TEXT="IC+"/>
<node CREATED="1438930370218" ID="ID_1837762412" MODIFIED="1438930375062" TEXT="&#x745e;&#x6631;"/>
<node CREATED="1438905959846" ID="ID_992682816" MODIFIED="1438905960825" TEXT="..."/>
</node>
</node>
<node CREATED="1438405416054" ID="ID_489960333" MODIFIED="1438929969156" TEXT="&#x7ad9;&#x70b9;">
<node CREATED="1438406408670" ID="ID_1909728734" LINK="https://www.openwrt.org/" MODIFIED="1438780111707" TEXT="https://www.openwrt.org/">
<node CREATED="1438780099243" ID="ID_1466319764" MODIFIED="1438780678915" TEXT="OpenWrt is described as a Linux distribution for embedded devices"/>
</node>
<node CREATED="1438414006834" ID="ID_1786596098" LINK="http://routerpwn.com" MODIFIED="1438780139103" TEXT="http://routerpwn.com">
<node CREATED="1438780476679" ID="ID_1932326430" MODIFIED="1438780620483" TEXT="&#x5168;&#x7403;&#x4e3b;&#x6d41;&#x8def;&#x7531;&#x5668;&#x76f8;&#x5173;&#x6f0f;&#x6d1e;&#x5927;&#x96c6;&#x5408;"/>
</node>
<node CREATED="1438406419563" ID="ID_1741743685" LINK="http://see.sl088.com/wiki/Uboot_%E7%BC%96%E8%AF%91" MODIFIED="1438780758228" TEXT="http://see.sl088.com/wiki/Uboot_%E7%BC%96%E8%AF%91">
<node CREATED="1438780696149" ID="ID_747407718" MODIFIED="1438780697093" TEXT="Uboot_&#x7f16;&#x8bd1;"/>
</node>
<node CREATED="1438405419918" ID="ID_1185471561" LINK="http://www.devttys0.com/" MODIFIED="1438780750305" TEXT="http://www.devttys0.com/">
<node CREATED="1438780733791" ID="ID_118174929" MODIFIED="1438780739872" TEXT="Embedded Device Hacking"/>
</node>
</node>
<node CREATED="1438590088993" ID="ID_551852599" MODIFIED="1438780836906" TEXT="&#x5de5;&#x5177;">
<node CREATED="1438590100385" ID="ID_544741815" MODIFIED="1438590123690" TEXT="Binwalk"/>
<node CREATED="1438590124839" ID="ID_1984127977" MODIFIED="1438590135978" TEXT="IDA Pro"/>
<node CREATED="1438591091833" ID="ID_1238270132" MODIFIED="1438591092852" TEXT="gdb/gdbserver"/>
<node CREATED="1438591159776" ID="ID_178155834" MODIFIED="1438591160758" TEXT="qemu-system"/>
<node CREATED="1438591167955" ID="ID_79110309" MODIFIED="1438591169047" TEXT="qemu-user-static"/>
<node CREATED="1438929914421" ID="ID_987306925" MODIFIED="1438905884097" TEXT="Smiasm"/>
<node CREATED="1438929941390" ID="ID_33810963" MODIFIED="1438905910049" TEXT="Metasm"/>
<node CREATED="1438930011281" ID="ID_502941254" MODIFIED="1438905949295" TEXT="JTAG&#x786c;&#x4ef6;&#x8c03;&#x8bd5;&#x5668;"/>
</node>
<node CREATED="1438404812376" ID="ID_1987049057" MODIFIED="1438929381421" TEXT="&#x4e66;">
<node CREATED="1438404818234" ID="ID_624181374" MODIFIED="1438779662858" TEXT="&#x300a;&#x63ed;&#x79d8;&#x5bb6;&#x7528;&#x8def;&#x7531;&#x5668;0day&#x6f0f;&#x6d1e;&#x6316;&#x6398;&#x6280;&#x672f;&#x300b;"/>
<node CREATED="1438932916803" ID="ID_554290162" MODIFIED="1438933114567" TEXT="&#x300a;Hacking the XBOX: An Introduction to Reverse Engineering&#x300b;"/>
<node CREATED="1438929453546" ID="ID_130836692" MODIFIED="1438933087779" TEXT="&#x300a;Hacking the Cable Modem: What Cable Companies Don&apos;t Want You to Know&#x300b;"/>
<node CREATED="1438929496062" HGAP="21" ID="ID_564392388" MODIFIED="1438933130330" TEXT="&#x300a;MIPS&#x4f53;&#x7cfb;&#x7ed3;&#x6784;&#x900f;&#x89c6; &#x300b;" VSHIFT="1"/>
<node CREATED="1438929589453" ID="ID_355904247" MODIFIED="1438933265729" TEXT="&#x300a;&#x8ba1;&#x7b97;&#x673a;&#x7ec4;&#x6210;&#x4e0e;&#x8bbe;&#x8ba1;&#xff1a;&#x786c;&#x4ef6;&#x3001;&#x8f6f;&#x4ef6;&#x63a5;&#x53e3;&#x300b;"/>
</node>
</node>
<node CREATED="1438405352273" ID="ID_290794013" MODIFIED="1438405355345" TEXT="&#x6444;&#x50cf;&#x5934;&#x5b89;&#x5168;">
<node CREATED="1438782912075" ID="ID_1010683994" LINK="http://www.openipcam.com/" MODIFIED="1438782924577" TEXT="http://www.openipcam.com/"/>
<node CREATED="1438790929611" ID="ID_1328904888" LINK="https://media.blackhat.com/us-13/US-13-Heffner-Exploiting-Network-Surveillance-Cameras-Like-A-Hollywood-Hacker-Slides.pdf" MODIFIED="1438790935258" TEXT="https://media.blackhat.com/us-13/US-13-Heffner-Exploiting-Network-Surveillance-Cameras-Like-A-Hollywood-Hacker-Slides.pdf"/>
</node>
<node CREATED="1438405731716" ID="ID_1286443438" MODIFIED="1438590198820" TEXT="&#x5de5;&#x63a7;&#x5b89;&#x5168;">
<node CREATED="1438646332451" ID="ID_557732250" MODIFIED="1438935774600" TEXT="&#x57fa;&#x7840;">
<node CREATED="1438646347866" ID="ID_1967238183" MODIFIED="1438784395291" TEXT="&#x5de5;&#x4e1a;&#x751f;&#x4ea7;&#x73af;&#x5883;&#x7684;&#x57fa;&#x672c;&#x7ed3;&#x6784;&#xff0c;&#x5982;&#xff1a;SCADA&#x3001;PCS"/>
<node CREATED="1438646376281" ID="ID_1643324881" MODIFIED="1438646518689" TEXT="&#x5de5;&#x4e1a;&#x751f;&#x4ea7;&#x73af;&#x5883;&#x7684;&#x4fe1;&#x606f;&#x5b89;&#x5168;&#x98ce;&#x9669;&#x70b9;&#xff08;&#x53ef;&#x53c2;&#x8003;DHS&#x51fa;&#x7248;&#x7269;&#xff09;">
<node CREATED="1438646525503" ID="ID_1496966071" MODIFIED="1438935862517" TEXT="Improving Industrial Control Systems Cybersecurity with Defense-In-Depth Strategies"/>
</node>
<node CREATED="1438646772726" ID="ID_1093585436" MODIFIED="1438646823937" TEXT="&#x5de5;&#x63a7;&#x7f51;&#x7edc;&#x7ec4;&#x6001;&#x3001;&#x903b;&#x8f91;&#x5f00;&#x53d1;&#x3001;&#x5e94;&#x7528;&#x7ec4;&#x6001;&#x7684;&#x57fa;&#x672c;&#x6280;&#x672f;&#x65b9;&#x6cd5;"/>
<node CREATED="1438646833388" ID="ID_1201985951" MODIFIED="1438784401539" TEXT="&#x6293;&#x5305;&#x3001;&#x770b;RFC&#x5206;&#x6790;&#x51e0;&#x4e2a;&#x5e38;&#x89c4;&#x5de5;&#x4e1a;&#x4ee5;&#x592a;&#x7f51;&#x534f;&#x8bae;&#xff0c;&#x5982;&#xff1a;Profinet&#x3001;Modbus"/>
<node CREATED="1438646964003" ID="ID_769839428" MODIFIED="1438647015657" TEXT="&#x4e70;&#x4e24;&#x6b3e;PLC&#x73a9;&#x73a9;&#xff0c;&#x4f1a;&#x771f;&#x5b9e;&#x611f;&#x53d7;&#x5230;&#x5de5;&#x4e1a;&#x73af;&#x5883;&#x7684;&#x4fe1;&#x606f;&#x5b89;&#x5168;&#x95ee;&#x9898;&#xff08;&#x4e00;&#x5b9a;&#x8bb0;&#x5f97;&#x4e70;&#x4ee5;&#x592a;&#x7f51;&#x6a21;&#x5757;&#xff0c;&#x4e0d;&#x8d35;&#x4e8c;&#x624b;&#x51e0;&#x767e;&#x5757;&#xff09;"/>
</node>
<node CREATED="1438644699338" ID="ID_1756501292" MODIFIED="1438783195050" TEXT="&#x7ad9;&#x70b9;">
<node CREATED="1438644786441" ID="ID_465046310" MODIFIED="1438783345744" TEXT="&#x4e8b;&#x4ef6;&#x8ddf;&#x8e2a;&#x5206;&#x6790;">
<node CREATED="1438644887385" ID="ID_719173369" LINK="http://plcscan.org/blog/  " MODIFIED="1438936150874" TEXT="http://plcscan.org/blog/"/>
<node CREATED="1438644945788" ID="ID_584771393" LINK="http://scadastrangelove.blogspot.kr" MODIFIED="1438784571579" TEXT="http://scadastrangelove.blogspot.kr"/>
<node CREATED="1438644971222" ID="ID_1559566452" LINK="http://www.phdays.com/ " MODIFIED="1438784577956" TEXT="http://www.phdays.com/"/>
<node CREATED="1438644978318" ID="ID_1670317879" LINK="http://www.scadasl.org " MODIFIED="1438784587581" TEXT="http://www.scadasl.org"/>
<node CREATED="1438645050422" ID="ID_673890089" LINK="https://scadahacker.com " MODIFIED="1438784595259" TEXT="https://scadahacker.com">
<node CREATED="1438646693938" ID="ID_88062802" MODIFIED="1438646699933" TEXT="Duqu">
<node CREATED="1438646701810" ID="ID_1487664587" LINK="https://scadahacker.com/resources/duqu.html " MODIFIED="1438784745162" TEXT="https://scadahacker.com/resources/duqu.html"/>
</node>
<node CREATED="1438646723320" ID="ID_255602414" MODIFIED="1438646728512" TEXT="Stuxnet">
<node CREATED="1438646728513" ID="ID_676853538" LINK="https://scadahacker.com/resources/stuxnet.html " MODIFIED="1438784751595" TEXT="https://scadahacker.com/resources/stuxnet.html"/>
</node>
<node CREATED="1438646758688" ID="ID_1836712041" MODIFIED="1438646763255" TEXT="Havex">
<node CREATED="1438646763256" ID="ID_1311679240" LINK="https://scadahacker.com/resources/havex.html" MODIFIED="1438784762571" TEXT="https://scadahacker.com/resources/havex.html"/>
</node>
</node>
</node>
<node CREATED="1438645432748" ID="ID_1782105303" MODIFIED="1438935931282" TEXT="&#x6807;&#x51c6;&#x534f;&#x4f1a;/&#x6d4b;&#x8bd5;&#x5de5;&#x5177;">
<node CREATED="1438645462761" ID="ID_1977269559" MODIFIED="1438645535702" TEXT="DHS CET&#x5957;&#x4ef6;">
<node CREATED="1438645515263" ID="ID_1908090665" LINK="http://ics-cert.us-cert.gov/Assessments " MODIFIED="1438784604189" TEXT="http://ics-cert.us-cert.gov/Assessments"/>
</node>
<node CREATED="1438645541020" ID="ID_183845374" MODIFIED="1438645550999" TEXT="NERC ES-ISAC">
<node CREATED="1438645552192" ID="ID_903378909" LINK="http://www.esisac.com/SitePages/Home.aspx " MODIFIED="1438784608961" TEXT="http://www.esisac.com/SitePages/Home.aspx"/>
</node>
<node CREATED="1438645582664" ID="ID_1254070824" MODIFIED="1438645595828" TEXT="ICS-ISAC">
<node CREATED="1438645595829" ID="ID_632601145" LINK="http://ics-isac.org " MODIFIED="1438784617309" TEXT="http://ics-isac.org"/>
</node>
<node CREATED="1438645629431" ID="ID_872078135" MODIFIED="1438645676845" TEXT="NTSB&#x7f8e;&#x56fd;&#x56fd;&#x5bb6;&#x5de5;&#x63a7;&#x6d4b;&#x8bd5;&#x5e8a;">
<node CREATED="1438645642943" ID="ID_103988901" LINK="http://energy.gov/oe/downloads/common-cyber-security-vulnerabilitiesobserved-control-system-assessments-inl-nstb " MODIFIED="1438784624452" TEXT="http://energy.gov/oe/downloads/common-cyber-security-vulnerabilitiesobserved-control-system-assessments-inl-nstb"/>
</node>
<node CREATED="1438645665525" ID="ID_999588815" MODIFIED="1438645673458" TEXT="NIST SP 800-82">
<node CREATED="1438645678975" ID="ID_399216892" LINK="http://csrc.nist.gov/publications/nistpubs/800-82/SP800-82-final.pdf " MODIFIED="1438784631932" TEXT="http://csrc.nist.gov/publications/nistpubs/800-82/SP800-82-final.pdf"/>
</node>
<node CREATED="1438645755306" ID="ID_1331027497" MODIFIED="1438645769362" TEXT="ISA-99&#x63a7;&#x5236;&#x7cfb;&#x7edf;&#x5b89;&#x5168;&#x534f;&#x4f1a;">
<node CREATED="1438645771337" ID="ID_346023747" LINK="http://isa99.isa.org/ISA99%20Wiki/Home.aspx " MODIFIED="1438784637532" TEXT="http://isa99.isa.org/ISA99%20Wiki/Home.aspx"/>
</node>
<node CREATED="1438645784931" ID="ID_525151725" MODIFIED="1438645790964" TEXT="NERC CIP&#x6807;&#x51c6;">
<node CREATED="1438645798403" ID="ID_656733468" LINK="http://www.nerc.com/pa/Stand/Pages/ReliabilityStandards.aspx " MODIFIED="1438784643666" TEXT="http://www.nerc.com/pa/Stand/Pages/ReliabilityStandards.aspx"/>
</node>
</node>
</node>
<node CREATED="1438646039140" ID="ID_1005171923" MODIFIED="1438783230228" TEXT="&#x5de5;&#x5177;">
<node CREATED="1438646205541" ID="ID_87483245" MODIFIED="1438646209474" TEXT="&#x4eff;&#x771f;&#x7c7b;">
<node CREATED="1438646121822" ID="ID_835109494" MODIFIED="1438783616617" TEXT="&#x7535;&#x529b;&#x4eff;&#x771f;&#x8f6f;&#x4ef6;testhaness"/>
<node CREATED="1438646142288" ID="ID_1970307365" MODIFIED="1438936205891" TEXT="Modbus&#x4eff;&#x771f;&#x8f6f;&#x4ef6;ModScan"/>
<node CREATED="1438646178953" ID="ID_18665617" MODIFIED="1438936218467" TEXT="&#x7535;&#x529b;104&#x534f;&#x8bae;&#x4eff;&#x771f;&#x8f6f;&#x4ef6;PMA"/>
</node>
<node CREATED="1438646213735" ID="ID_238822566" MODIFIED="1438646216577" TEXT="&#x6d4b;&#x8bd5;&#x7c7b;">
<node CREATED="1438646218332" ID="ID_1033383466" MODIFIED="1438906074874" TEXT="Wurldtech Achilles"/>
<node CREATED="1438646232272" ID="ID_303285435" MODIFIED="1438906091181" TEXT="Codenomicon Defensics"/>
<node CREATED="1438646245324" ID="ID_250240638" MODIFIED="1438646249930" TEXT="Spirent"/>
<node CREATED="1438646250419" ID="ID_604926018" MODIFIED="1438646255372" TEXT="BPS"/>
</node>
<node CREATED="1438645055662" ID="ID_597151567" MODIFIED="1438783351853" TEXT="&#x6e90;&#x4ee3;&#x7801;">
<node CREATED="1438645078523" ID="ID_78314865" MODIFIED="1438783353941" TEXT="&#x53d1;&#x73b0;">
<node CREATED="1438645087674" ID="ID_204868207" LINK="https://code.google.com/p/plcscan/ &#x9; " MODIFIED="1438784654737" TEXT="https://code.google.com/p/plcscan/ &#x9;"/>
<node CREATED="1438645108151" ID="ID_1864529001" LINK="https://code.google.com/p/modscan/ &#x9; " MODIFIED="1438784662210" TEXT="https://code.google.com/p/modscan/ &#x9;"/>
<node CREATED="1438645128373" ID="ID_1856202126" LINK="https://github.com/arnaudsoullie/scan7 &#x9; " MODIFIED="1438784668917" TEXT="https://github.com/arnaudsoullie/scan7 &#x9;"/>
<node CREATED="1438645138467" ID="ID_1199890815" LINK="https://github.com/atimorin " MODIFIED="1438784674824" TEXT="https://github.com/atimorin"/>
<node CREATED="1438645287385" ID="ID_1663877082" LINK="https://github.com/digitalbond/Redpoint " MODIFIED="1438784680633" TEXT="https://github.com/digitalbond/Redpoint"/>
</node>
<node CREATED="1438645150825" ID="ID_523924931" MODIFIED="1438783357221" TEXT="&#x64cd;&#x7eb5;">
<node CREATED="1438645156783" ID="ID_1830008052" LINK="https://www.scadaforce.com/modbus " MODIFIED="1438784688733" TEXT="https://www.scadaforce.com/modbus"/>
<node CREATED="1438645186829" ID="ID_233011592" LINK="https://github.com/bashwork/pymodbus " MODIFIED="1438784697507" TEXT="https://github.com/bashwork/pymodbus"/>
<node CREATED="1438645201533" ID="ID_587167778" LINK="https://rubygems.org/gems/modbus-cli " MODIFIED="1438784703043" TEXT="https://rubygems.org/gems/modbus-cli"/>
<node CREATED="1438645210421" ID="ID_446487698" LINK="http://libnodave.sourceforge.net " MODIFIED="1438784713156" TEXT="http://libnodave.sourceforge.net"/>
<node CREATED="1438645220988" ID="ID_927452417" LINK="https://code.google.com/p/dnp3 " MODIFIED="1438784719381" TEXT="https://code.google.com/p/dnp3"/>
</node>
<node CREATED="1438645246454" ID="ID_1032686966" MODIFIED="1438783399273" TEXT="&#x5f02;&#x5e38;&#x76d1;&#x6d4b;">
<node CREATED="1438645255864" ID="ID_1758153877" LINK="http://blog.snort.org/2012/01/snort-292-scada-preprocessors.html &#x9; " MODIFIED="1438784724847" TEXT="http://blog.snort.org/2012/01/snort-292-scada-preprocessors.html &#x9;"/>
<node CREATED="1438645262816" ID="ID_1622090211" LINK="http://www.digitalbond.com/tools/quickdraw/ " MODIFIED="1438784730569" TEXT="http://www.digitalbond.com/tools/quickdraw/"/>
</node>
<node CREATED="1438645276180" ID="ID_712990324" MODIFIED="1438783402351" TEXT="Fuzz">
<node CREATED="1438645283472" ID="ID_1640940252" LINK="https://github.com/jseidl/peach-pit/blob/master/modbus/modbus.xml " MODIFIED="1438784737107" TEXT="https://github.com/jseidl/peach-pit/blob/master/modbus/modbus.xml"/>
</node>
</node>
</node>
<node CREATED="1438644671803" ID="ID_1935076845" MODIFIED="1438936392601" TEXT="&#x5176;&#x4ed6;">
<node CREATED="1438644710590" ID="ID_978359672" LINK=" http://ics.zoomeye.org/" MODIFIED="1439031354631" TEXT="ZoomEye&#x5de5;&#x63a7;&#x4e13;&#x9898;&#xff1a; http://ics.zoomeye.org/"/>
<node CREATED="1438644733816" ID="ID_460697430" LINK="https://www.shodan.io/report/l7VjfVKc" MODIFIED="1439031360307" TEXT="Shodan&#x5de5;&#x63a7;&#x4e13;&#x9898;&#xff1a;https://www.shodan.io/report/l7VjfVKc"/>
<node CREATED="1438936395417" ID="ID_729692202" LINK="https://github.com/evilcos/papers/blob/master/&#x7f51;&#x7edc;&#x7a7a;&#x95f4;&#x5de5;&#x63a7;&#x8bbe;&#x5907;&#x7684;&#x53d1;&#x73b0;&#x4e0e;&#x5165;&#x4fb5;.ppt" MODIFIED="1438936424786" TEXT="https://github.com/evilcos/papers/blob/master/&#x7f51;&#x7edc;&#x7a7a;&#x95f4;&#x5de5;&#x63a7;&#x8bbe;&#x5907;&#x7684;&#x53d1;&#x73b0;&#x4e0e;&#x5165;&#x4fb5;.ppt"/>
</node>
</node>
<node CREATED="1438781832583" ID="ID_164776763" MODIFIED="1438781835848" TEXT="zoomeye.org">
<node CREATED="1438781843517" ID="ID_1689998733" MODIFIED="1438782621810" TEXT="&#x5168;&#x7403;&#x53ef;&#x4ee5;&#x627e;&#x5230;&#x65e0;&#x6570;&#x771f;&#x5b9e;&#x8def;&#x7531;&#x5668;/&#x6444;&#x50cf;&#x5934;/&#x5de5;&#x63a7;&#x8bbe;&#x5907;&#x7b49;"/>
<node CREATED="1438781897341" ID="ID_1403294261" LINK="http://www.zoomeye.org/search?q=app:%22MikroTik%20RouterOS%22&amp;from=dork" MODIFIED="1438781913126" TEXT="&#x5982;&#xff1a;http://www.zoomeye.org/search?q=app:%22MikroTik%20RouterOS%22&amp;from=dork"/>
</node>
</node>
<node CREATED="1394122225252" ID="ID_1866793548" MODIFIED="1438940727682" TEXT="&#x7814;&#x53d1;&#x6e05;&#x5355;">
<node CREATED="1394104556794" ID="ID_348203788" MODIFIED="1438407148159" TEXT="&#x7f16;&#x7801;&#x73af;&#x5883;">
<node CREATED="1394104580694" ID="ID_160705865" MODIFIED="1394104589584" TEXT="pip"/>
<node CREATED="1394104578561" ID="ID_1056764018" MODIFIED="1463563673013" TEXT="Docker/Vagrant"/>
<node CREATED="1394104563587" ID="ID_357951095" MODIFIED="1394126858967" TEXT="tmux/screen"/>
<node CREATED="1394104614942" ID="ID_1019971551" MODIFIED="1438785115710" TEXT="vim"/>
<node COLOR="#000000" CREATED="1438407158337" ID="ID_1350573813" MODIFIED="1438785142042" TEXT="Markdown"/>
<node CREATED="1394104630070" ID="ID_393146269" MODIFIED="1394126851535" TEXT="zsh + oh-my-zsh"/>
<node CREATED="1394104697289" ID="ID_1700888094" MODIFIED="1463563676258" TEXT="Python2.7+/3+"/>
<node CREATED="1394104710383" ID="ID_586585248" MODIFIED="1394126956592" TEXT="&gt;Django1.4">
<node CREATED="1355815985826" ID="ID_947674828" LINK="http://djangobook.py3k.cn/2.0/" MODIFIED="1394165136354" TEXT="http://djangobook.py3k.cn/2.0/"/>
<node COLOR="#000000" CREATED="1438403748531" ID="ID_304997068" LINK="http://django-debug-toolbar.readthedocs.org/en/latest/" MODIFIED="1438785470834" TEXT="Django Debug Toolbar"/>
<node CREATED="1438785478806" ID="ID_23425945" MODIFIED="1438785484262" TEXT="&#x5176;&#x4ed6;&#x6846;&#x67b6;">
<node CREATED="1438785489561" ID="ID_409387236" MODIFIED="1438785493496" TEXT="web.py"/>
<node CREATED="1438785493739" ID="ID_331623019" MODIFIED="1438785496974" TEXT="Flask"/>
<node CREATED="1438785497571" ID="ID_1314336718" MODIFIED="1438785500384" TEXT="Tornado"/>
</node>
</node>
<node CREATED="1394105681045" ID="ID_744721568" MODIFIED="1394105686601" TEXT="node.js"/>
<node CREATED="1394104746881" ID="ID_1442580270" MODIFIED="1394126980659" TEXT="Ubuntu/Gentoo/Centos"/>
<node CREATED="1394104873272" ID="ID_1573870855" MODIFIED="1394104878750" TEXT="ipython"/>
<node CREATED="1394105553790" ID="ID_518662877" MODIFIED="1394105570493" TEXT="&#x7248;&#x672c;&#x63a7;&#x5236;">
<node CREATED="1438785514507" ID="ID_411014012" MODIFIED="1438785549611" TEXT="&#x5e9f;&#x5f03;SVN&#xff0c;&#x5168;&#x9762;&#x62e5;&#x62b1;Git"/>
<node CREATED="1394105572408" ID="ID_1567627202" MODIFIED="1438785576991" TEXT="GitLab"/>
</node>
<node CREATED="1394106614839" ID="ID_1738360829" MODIFIED="1394127024041" TEXT="Nginx+uWSGI"/>
</node>
<node CREATED="1354455667877" ID="ID_596426216" MODIFIED="1438785589445" TEXT="Python">
<node CREATED="1354522127859" ID="ID_729169681" MODIFIED="1357466329785" TEXT="&#x5b98;&#x65b9;&#x624b;&#x518c;">
<node CREATED="1366587810674" ID="ID_1596127970" MODIFIED="1366587838671" TEXT="&#x81f3;&#x5c11;&#x8fc7;&#x4e00;&#x904d;&#xff0c;&#x8fd9;&#x90fd;&#x6ca1;&#x8fc7;&#x4e00;&#x904d;&#xff0c;&#x89c6;&#x91ce;&#x4f1a;&#x5c40;&#x9650;"/>
<node CREATED="1394121577958" ID="ID_1028057675" MODIFIED="1438785606670" TEXT="&#x884c;&#x4e4b;&#x8bf4;&#xff1a;&#x300c;&#x6211;&#x6ca1;&#x770b;&#x8fc7;Python&#x7684;&#x4e66;&#xff0c;&#x5374;&#x719f;&#x8bfb;&#x5b98;&#x65b9;&#x624b;&#x518c;...&#x300d;"/>
</node>
</node>
<node CREATED="1354455670555" ID="ID_1770370490" MODIFIED="1439082619791" TEXT="Linux/UNIX">
<node CREATED="1354522112941" ID="ID_951565481" MODIFIED="1357466329785" TEXT="&#x4e66;">
<node CREATED="1438785657853" ID="ID_812384059" MODIFIED="1438785659197" TEXT="&#x300a;&#x9e1f;&#x54e5;&#x7684;Linux&#x79c1;&#x623f;&#x83dc;&#x300b;"/>
<node CREATED="1438785798405" ID="ID_1963735482" MODIFIED="1438785801171" TEXT="&#x300a;Linux Shell&#x811a;&#x672c;&#x653b;&#x7565;&#x300b;"/>
<node CREATED="1438785773086" ID="ID_1816282407" MODIFIED="1438785777102" TEXT="&#x300a;UNIX&#x7f16;&#x7a0b;&#x827a;&#x672f;&#x300b;"/>
<node CREATED="1438785980157" ID="ID_1454797853" MODIFIED="1438786001869" TEXT="&#x300a;Software Design &#x4e2d;&#x6587;&#x7248; 01&#x300b;&#x300a;Software Design &#x4e2d;&#x6587;&#x7248; 02&#x300b;&#x300a;Software Design &#x4e2d;&#x6587;&#x7248; 03&#x300b;"/>
</node>
<node CREATED="1438785870623" ID="ID_1376405028" MODIFIED="1438785916076" TEXT="&#x8ba9;&#x4f60;&#x7684;&#x7535;&#x8111;&#x9ed8;&#x8ba4;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x5c31;&#x662f;Linux..."/>
</node>
<node CREATED="1354694228667" ID="ID_168689321" MODIFIED="1438406714877" TEXT="&#x524d;&#x7aef;">
<node CREATED="1354694232561" ID="ID_632752890" MODIFIED="1357466329786" TEXT="&#x4e66;">
<node CREATED="1354694240139" ID="ID_1299498841" MODIFIED="1438785837545" TEXT="&#x300a;JavaScript DOM&#x7f16;&#x7a0b;&#x827a;&#x672f;&#x300b;"/>
</node>
<node CREATED="1354694250616" ID="ID_192696826" MODIFIED="1357466329787" TEXT="&#x4e86;&#x89e3;DOM">
<node CREATED="1354694335263" ID="ID_139793976" MODIFIED="1357466329787" TEXT="&#x8fd9;&#x540c;&#x6837;&#x662f;&#x641e;&#x597d;&#x524d;&#x7aef;&#x5b89;&#x5168;&#x7684;&#x5fc5;&#x8981;&#x57fa;&#x7840;"/>
</node>
<node CREATED="1354694260516" ID="ID_487844159" MODIFIED="1357466329787" TEXT="&#x5e93;">
<node CREATED="1354694262777" ID="ID_1624301717" MODIFIED="1394121655106" TEXT="jQuery">
<node CREATED="1354694288421" ID="ID_1676442171" MODIFIED="1357466329787" TEXT="&#x4f18;&#x79c0;&#x7684;&#x63d2;&#x4ef6;&#x5e94;&#x8be5;&#x4f53;&#x9a8c;&#x4e00;&#x904d;&#xff0c;&#x5e76;&#x505a;&#x4e9b;&#x5c1d;&#x8bd5;"/>
<node CREATED="1354694312426" ID="ID_1141271616" MODIFIED="1357466329788" TEXT="&#x5b98;&#x65b9;&#x6587;&#x6863;&#x5f97;&#x8fc7;&#x4e00;&#x904d;"/>
</node>
<node COLOR="#000000" CREATED="1438406718838" ID="ID_1804399103" MODIFIED="1438786042980" TEXT="D3.js"/>
<node CREATED="1394121685819" ID="ID_1800885556" MODIFIED="1394121689487" TEXT="ECharts">
<node CREATED="1394121820782" ID="ID_1659404357" MODIFIED="1394121822341" TEXT="&#x6765;&#x81ea;&#x767e;&#x5ea6;"/>
</node>
<node CREATED="1394121701570" ID="ID_1902173969" MODIFIED="1394121706537" TEXT="Google API"/>
<node CREATED="1394121712976" ID="ID_1096812023" MODIFIED="1394121722885" TEXT="ZoomEye Map&#x7ec4;&#x4ef6;">
<node CREATED="1394121796186" ID="ID_428278156" MODIFIED="1394121808011" TEXT="ZoomEye&#x56e2;&#x961f;&#x81ea;&#x5df1;&#x57fa;&#x4e8e;&#x5f00;&#x6e90;&#x7684;&#x6253;&#x9020;"/>
</node>
<node CREATED="1394121733215" ID="ID_1424819835" MODIFIED="1394121752065" TEXT="AngularJS">
<node CREATED="1394121753530" ID="ID_1879459007" MODIFIED="1394121788441" TEXT="Google&#x51fa;&#x54c1;&#x7684;&#x98a0;&#x8986;&#x6027;&#x524d;&#x7aef;&#x6846;&#x67b6;"/>
</node>
<node CREATED="1354694269025" ID="ID_144254280" MODIFIED="1394121642439" TEXT="Bootstrap">
<node CREATED="1354694321464" ID="ID_1468897847" MODIFIED="1357466329788" TEXT="&#x5e94;&#x8be5;&#x4f7f;&#x7528;&#x4e00;&#x904d;"/>
</node>
</node>
</node>
<node CREATED="1394128076466" ID="ID_864113907" MODIFIED="1438786052650" TEXT="&#x722c;&#x866b;&#x8fdb;&#x9636;">
<node CREATED="1394102556343" ID="ID_1179940181" MODIFIED="1394127711424" TEXT="&#x4ee3;&#x7406;&#x6c60;">
<node CREATED="1394124125892" ID="ID_472980254" MODIFIED="1394124452699" TEXT="&#x722c;&#x866b;&#x300c;&#x7a33;&#x5b9a;&#x300d;&#x9700;&#x8981;"/>
</node>
<node CREATED="1394105341853" ID="ID_338059399" MODIFIED="1394127380660" TEXT="&#x7f51;&#x7edc;&#x8bf7;&#x6c42;">
<node CREATED="1394105353859" ID="ID_23682719" MODIFIED="1394105364894" TEXT="wget/curl"/>
<node CREATED="1394105365986" ID="ID_1171894669" MODIFIED="1394105376937" TEXT="urllib2/httplib2/requests"/>
<node CREATED="1394105377684" ID="ID_1842328932" MODIFIED="1394127391408" TEXT="scrapy">
<icon BUILTIN="idea"/>
</node>
</node>
<node CREATED="1394105404671" ID="ID_1398548144" MODIFIED="1394105408086" TEXT="&#x9a8c;&#x8bc1;&#x7801;&#x7834;&#x89e3;">
<node CREATED="1394127436560" ID="ID_387264815" MODIFIED="1394127440577" TEXT="pytesser"/>
</node>
</node>
<node CREATED="1394103209408" ID="ID_1502296884" MODIFIED="1438786066027" TEXT="&#x8c03;&#x5ea6;">
<node CREATED="1394126400722" ID="ID_1933802250" MODIFIED="1394126439763" TEXT="crontab&#x662f;&#x6700;&#x539f;&#x751f;&#x7684;&#x5b9a;&#x65f6;&#x8c03;&#x5ea6;"/>
<node CREATED="1394103388627" ID="ID_1786100474" MODIFIED="1394126453798" TEXT="&#x57fa;&#x4e8e;redis&#x5b9e;&#x73b0;&#x7684;&#x5206;&#x5e03;&#x5f0f;&#x8c03;&#x5ea6;"/>
<node CREATED="1394103489138" ID="ID_1220728032" MODIFIED="1394126478601" TEXT="&#x57fa;&#x4e8e;rpyc&#x5b9e;&#x73b0;&#x7684;&#x5206;&#x5e03;&#x5f0f;&#x8c03;&#x5ea6;"/>
<node CREATED="1394103738598" ID="ID_1318851770" MODIFIED="1394126493928" TEXT="celery/gearman&#x7b49;&#x8c03;&#x5ea6;&#x6846;&#x67b6;"/>
</node>
<node CREATED="1394128158597" ID="ID_1472189728" MODIFIED="1438786076412" TEXT="&#x5e76;&#x53d1;">
<node CREATED="1394102760429" ID="ID_1534687322" MODIFIED="1394124136221" TEXT="&#x7ebf;&#x7a0b;&#x6c60;">
<node CREATED="1394102764489" ID="ID_1489972607" MODIFIED="1394124495516" TEXT="&#x8fdb;&#x7a0b;&#x5185;&#x4f18;&#x7f8e;&#x7684;&#x5e76;&#x53d1;&#x65b9;&#x6848;"/>
</node>
<node CREATED="1394102781469" ID="ID_374818193" MODIFIED="1394125091346" TEXT="&#x534f;&#x7a0b;">
<node CREATED="1394102787152" ID="ID_622070629" MODIFIED="1394125111903" TEXT="&#x8fdb;&#x7a0b;&#x5185;&#x53e6;&#x4e00;&#x79cd;&#x4f18;&#x7f8e;&#x7684;&#x5e76;&#x53d1;&#x65b9;&#x6848;"/>
<node CREATED="1438786080180" ID="ID_1099982854" MODIFIED="1438786083052" TEXT="gevent"/>
</node>
<node CREATED="1394102801068" ID="ID_210910885" MODIFIED="1394125601699" TEXT="&#x591a;&#x8fdb;&#x7a0b;">
<node CREATED="1394103083380" ID="ID_338148384" MODIFIED="1394103092116" TEXT="os.fork"/>
<node CREATED="1394102809083" ID="ID_1142852185" MODIFIED="1394185192103" TEXT="multiprocessing">
<icon BUILTIN="idea"/>
</node>
</node>
</node>
<node CREATED="1394104090688" ID="ID_1412849515" MODIFIED="1394128271513" TEXT="&#x6570;&#x636e;&#x7ed3;&#x6784;">
<node CREATED="1394104127216" ID="ID_1783054235" MODIFIED="1394126682023" TEXT="JSON"/>
<node CREATED="1394104012323" ID="ID_1807436439" MODIFIED="1394104029171" TEXT="cPickle"/>
<node CREATED="1394104030611" ID="ID_1971934054" MODIFIED="1394104065684" TEXT="protobuf"/>
</node>
<node COLOR="#000000" CREATED="1438406820761" ID="ID_1036213143" MODIFIED="1438786139991" TEXT="&#x6570;&#x636e;&#x5b58;&#x50a8;&#x53ca;&#x5904;&#x7406;">
<node CREATED="1394103899803" ID="ID_1119685856" MODIFIED="1438406843965" TEXT="&#x6570;&#x636e;&#x5e93;">
<node CREATED="1394103906506" ID="ID_697093356" MODIFIED="1394126627849" TEXT="MySQL"/>
<node CREATED="1394103909850" ID="ID_1277190468" MODIFIED="1438790522291" STYLE="fork" TEXT="MongoDB"/>
<node CREATED="1394103918809" ID="ID_8101948" MODIFIED="1394126641135" TEXT="Cassandra"/>
<node CREATED="1394103928557" ID="ID_967096777" MODIFIED="1394126648299" TEXT="Hadoop&#x4f53;&#x7cfb;"/>
<node CREATED="1394103972294" ID="ID_171067558" MODIFIED="1394126652143" TEXT="Redis"/>
<node CREATED="1394103974371" ID="ID_347170230" MODIFIED="1394126666277" TEXT="Sqlite"/>
<node CREATED="1394103993741" ID="ID_788056121" MODIFIED="1394104005693" TEXT="bsddb"/>
<node COLOR="#000000" CREATED="1438404193108" ID="ID_1553928588" MODIFIED="1438786096838" TEXT="ElasticSearch"/>
</node>
<node COLOR="#000000" CREATED="1438406865878" ID="ID_1865991964" MODIFIED="1438786117972" TEXT="&#x5927;&#x6570;&#x636e;&#x5904;&#x7406;">
<node CREATED="1438406871108" ID="ID_1273269222" MODIFIED="1438406874689" TEXT="Hive"/>
<node CREATED="1438406878193" ID="ID_1928668952" MODIFIED="1438406880396" TEXT="Spark"/>
<node CREATED="1438406968114" ID="ID_738630408" MODIFIED="1438406970172" TEXT="ELK">
<node CREATED="1438406972700" ID="ID_1504720397" MODIFIED="1438406983931" TEXT="ElasticSearch "/>
<node CREATED="1438406984365" ID="ID_313975863" MODIFIED="1438406991707" TEXT="Logstash"/>
<node CREATED="1438406999588" ID="ID_1259581560" MODIFIED="1438407004428" TEXT="Kibana"/>
</node>
</node>
</node>
<node CREATED="1394104282376" ID="ID_1316431399" MODIFIED="1438786143138" TEXT="DevOps">
<node CREATED="1394104304882" ID="ID_1574882170" MODIFIED="1394126037938" TEXT="SSH&#x8bc1;&#x4e66;"/>
<node CREATED="1394103067906" ID="ID_1265468169" MODIFIED="1394125968210" TEXT="Fabric"/>
<node CREATED="1394104382505" ID="ID_1733986479" MODIFIED="1394126095678" TEXT="SaltStack"/>
<node CREATED="1394104414034" ID="ID_1561208156" MODIFIED="1394104423118" TEXT="puppet"/>
<node CREATED="1394104431571" ID="ID_1691834633" MODIFIED="1394104538568" TEXT="pssh/dsh"/>
<node CREATED="1399728878860" ID="ID_1049294292" MODIFIED="1399728883878" TEXT="&#x8fd0;&#x7ef4;&#x8fdb;&#x9636;">
<node CREATED="1399728899156" ID="ID_829397824" MODIFIED="1399728900273" TEXT="&#x8fd0;&#x7ef4;&#x5de5;&#x7a0b;&#x5e08;&#x5fc5;&#x987b;&#x638c;&#x63e1;&#x7684;&#x57fa;&#x7840;&#x6280;&#x80fd;&#x6709;&#x54ea;&#x4e9b;&#xff1f;"/>
<node CREATED="1399728886465" ID="ID_1695838165" LINK="http://www.zhihu.com/question/23665108/answer/25299881" MODIFIED="1399728934385" TEXT="http://www.zhihu.com/question/23665108/answer/25299881"/>
</node>
</node>
<node CREATED="1394104859791" ID="ID_1148466125" MODIFIED="1438786260924" TEXT="&#x8c03;&#x8bd5;">
<node CREATED="1394104864419" ID="ID_120167821" MODIFIED="1394104884622" TEXT="pdb"/>
<node CREATED="1394104885293" ID="ID_1334881656" MODIFIED="1394127085767" TEXT="logging"/>
<node CREATED="1394104917938" ID="ID_1776509221" MODIFIED="1394127106604" TEXT="Sentry"/>
<node CREATED="1394105092835" ID="ID_79123748" MODIFIED="1394105326860" TEXT="strace/ltrace"/>
<node CREATED="1394105208694" ID="ID_652590354" MODIFIED="1394105210780" TEXT="lsof"/>
<node CREATED="1394104932448" ID="ID_1436262800" MODIFIED="1394104946333" TEXT="&#x6027;&#x80fd;">
<node CREATED="1394104949387" ID="ID_1592692247" MODIFIED="1394127375878" TEXT="Python&#x5185;">
<node CREATED="1394105079667" ID="ID_806385547" MODIFIED="1394105088589" TEXT="timeit"/>
<node CREATED="1394104962661" ID="ID_1310758192" MODIFIED="1394104984201" TEXT="cProfile"/>
<node CREATED="1394105074845" ID="ID_1305908852" LINK="http://www.oschina.net/translate/python-performance-analysis" MODIFIED="1394165104164" TEXT="Python&#x6027;&#x80fd;&#x5206;&#x6790;&#x6307;&#x5357;&#xff1a;http://www.oschina.net/translate/python-performance-analysis"/>
</node>
<node CREATED="1394104957560" ID="ID_1956484518" MODIFIED="1394127372826" TEXT="Python&#x5916;">
<node CREATED="1394105115820" ID="ID_391946801" MODIFIED="1394127369072" TEXT="top/htop/free/iostat/vmstat/ifconfig/iftop..."/>
</node>
</node>
</node>
<node CREATED="1354675490875" ID="ID_1743415345" MODIFIED="1438786270948" TEXT="&#x7b97;&#x6cd5;">
<node CREATED="1354694874139" ID="ID_1501017600" MODIFIED="1357466329798" TEXT="&#x5206;&#x8bcd;"/>
<node CREATED="1354675493318" ID="ID_478609653" MODIFIED="1357466329798" TEXT="&#x8d1d;&#x53f6;&#x65af;"/>
<node CREATED="1354694357792" ID="ID_391609972" MODIFIED="1357466329799" TEXT="&#x795e;&#x7ecf;&#x5143;"/>
<node CREATED="1354694359973" ID="ID_1245075441" MODIFIED="1357466329799" TEXT="&#x9057;&#x4f20;&#x7b97;&#x6cd5;"/>
<node CREATED="1394127950410" ID="ID_501087655" MODIFIED="1394127954639" TEXT="&#x805a;&#x7c7b;/&#x5206;&#x7c7b;"/>
<node CREATED="1366588688634" ID="ID_1143044200" MODIFIED="1366588692098" TEXT="..."/>
</node>
<node CREATED="1394105468154" ID="ID_1462638174" MODIFIED="1394127460328" TEXT="&#x6301;&#x7eed;&#x96c6;&#x6210;">
<node CREATED="1394105448307" ID="ID_119293728" MODIFIED="1394105458900" TEXT="&#x81ea;&#x6d4b;&#x8bd5;">
<node CREATED="1394105459881" ID="ID_895054548" MODIFIED="1394105467143" TEXT="nose"/>
</node>
<node CREATED="1394105486115" ID="ID_852196341" MODIFIED="1394127522198" TEXT="Jenkins"/>
</node>
<node CREATED="1439032290081" ID="ID_123373449" MODIFIED="1439033573903" TEXT="&#x5b89;&#x5168;">
<icon BUILTIN="idea"/>
<node CREATED="1439032294533" ID="ID_1436643535" MODIFIED="1439032324528" TEXT="&#x6211;&#x7684;&#x5206;&#x4eab;">
<node CREATED="1439032325369" ID="ID_1447092803" LINK="http://www.infoq.com/cn/presentations/programmers-and-hackers" MODIFIED="1439032365934" TEXT="&#x7a0b;&#x5e8f;&#x5458;&#x4e0e;&#x9ed1;&#x5ba2;&#xff1a;http://www.infoq.com/cn/presentations/programmers-and-hackers"/>
<node CREATED="1463562217703" ID="ID_345942828" LINK="http://www.infoq.com/cn/presentations/programmers-and-hackers-part02" MODIFIED="1463562251560" TEXT="&#x7a0b;&#x5e8f;&#x5458;&#x4e0e;&#x9ed1;&#x5ba2;2&#xff1a;http://www.infoq.com/cn/presentations/programmers-and-hackers-part02"/>
</node>
</node>
<node CREATED="1394106554124" ID="ID_179264180" MODIFIED="1394128003797" TEXT="&#x534f;&#x4f5c;">
<node CREATED="1394106559415" ID="ID_47775890" MODIFIED="1394128040655" TEXT="&#x7c7b;&#x4f3c;Trello&#x7684;&#x5728;&#x7ebf;&#x534f;&#x540c;&#x5e73;&#x53f0;"/>
<node COLOR="#000000" CREATED="1438406800973" ID="ID_783162352" MODIFIED="1438786285936" TEXT="Slack"/>
<node CREATED="1394106571166" ID="ID_1275665131" MODIFIED="1394106573010" TEXT="&#x5fae;&#x4fe1;"/>
<node CREATED="1394106577713" ID="ID_1786087671" MODIFIED="1394106583720" TEXT="&#x7acb;&#x4f1a;"/>
</node>
</node>
<node CREATED="1354520897807" ID="ID_320715661" MODIFIED="1438940729918" TEXT="&#x8bbe;&#x8ba1;&#x601d;&#x60f3;">
<node CREATED="1354520905459" ID="ID_367293839" MODIFIED="1394122107830" TEXT="&#x4eba;&#x4eba;&#x90fd;&#x662f;&#x67b6;&#x6784;&#x5e08;&#xff1a;&#x5177;&#x5907;&#x67b6;&#x6784;&#x601d;&#x60f3;&#x662f;&#x4e00;&#x4ef6;&#x591a;&#x9177;&#x7684;&#x4e8b;"/>
<node CREATED="1354694828358" ID="ID_114782203" MODIFIED="1357466329795" TEXT="&#x5b9e;&#x6218;&#x51fa;&#x771f;&#x77e5;"/>
<node CREATED="1354695540203" ID="ID_684870389" MODIFIED="1357466329795" TEXT="&#x5982;&#x4f55;&#x8bbe;&#x8ba1;">
<node CREATED="1354695495994" ID="ID_1401157496" LINK="res/arch_design_evolution.pdf" MODIFIED="1439032132438" TEXT="&#x4efb;&#x52a1;&#x67b6;&#x6784;&#x8bbe;&#x8ba1;&#x53d8;&#x8fc1;.pdf">
<icon BUILTIN="attach"/>
</node>
<node CREATED="1354695555881" ID="ID_56173025" MODIFIED="1357466329796" TEXT="&#x677e;&#x8026;&#x5408;&#x3001;&#x7d27;&#x5185;&#x805a;"/>
<node CREATED="1354695549804" ID="ID_1124193783" MODIFIED="1357466329796" TEXT="&#x5355;&#x5143;&#x4e0e;&#x5355;&#x5143;&#x5c5e;&#x6027;"/>
<node CREATED="1354695567781" ID="ID_589374981" MODIFIED="1357466329796" TEXT="&#x751f;&#x4ea7;&#x8005;&#x4e0e;&#x6d88;&#x8d39;&#x8005;"/>
<node CREATED="1354695635465" ID="ID_1161888095" MODIFIED="1357466329796" TEXT="&#x7ed3;&#x6784;">
<node CREATED="1354695637815" ID="ID_1147348960" MODIFIED="1357466329796" TEXT="&#x961f;&#x5217;"/>
<node CREATED="1354695644469" ID="ID_1803463998" MODIFIED="1357466329797" TEXT="LRU"/>
</node>
<node CREATED="1354695622416" ID="ID_1589634672" MODIFIED="1357466329797" TEXT="&#x5206;&#x5e03;&#x5f0f;">
<node CREATED="1354695624862" ID="ID_1754272354" MODIFIED="1357466329797" TEXT="&#x5b58;&#x50a8;"/>
<node CREATED="1354695626059" ID="ID_206732776" MODIFIED="1357466329797" TEXT="&#x8ba1;&#x7b97;"/>
</node>
<node CREATED="1354695656240" ID="ID_512963126" MODIFIED="1357466329797" TEXT="&#x8d44;&#x6e90;&#x8003;&#x8651;">
<node CREATED="1354695658810" ID="ID_249396941" MODIFIED="1357466329797" TEXT="CPU"/>
<node CREATED="1354695660996" ID="ID_353673434" MODIFIED="1357466329798" TEXT="&#x5185;&#x5b58;"/>
<node CREATED="1354695663537" ID="ID_465774011" MODIFIED="1357466329798" TEXT="&#x5e26;&#x5bbd;"/>
</node>
<node CREATED="1366590214127" ID="ID_1809570933" MODIFIED="1366590243153" TEXT="&#x7c97;&#x66b4;&#x7f8e;&#x5b66;/&#x66b4;&#x529b;&#x7f8e;&#x5b66;">
<node CREATED="1366590246021" ID="ID_974898994" MODIFIED="1394122145107" TEXT="&#x5927;&#x6570;&#x636e;&#xff0c;&#x5148;&#x8003;&#x8651;run it&#xff0c;&#x7136;&#x540e;&#x624d;&#x80fd;&#x77e5;&#x9053;&#x89c4;&#x5f8b;&#x5728;&#x54ea;"/>
<node CREATED="1366590279656" ID="ID_1371080158" MODIFIED="1394122156116" TEXT="&#x300c;run it&#x4f18;&#x5148;&#x300d;&#x80fd;&#x5feb;&#x901f;&#x6253;&#x901a;&#x6574;&#x4f53;&#xff0c;&#x6d1e;&#x5bdf;&#x95ee;&#x9898;"/>
<node CREATED="1366590354621" ID="ID_1716122245" MODIFIED="1394122163232" TEXT="&#x300c;run it&#x4f18;&#x5148;&#x300d;&#x80fd;&#x6446;&#x8131;&#x7ec6;&#x8282;&#xff08;&#x7e41;&#x679d;&#x672b;&#x8282;&#xff09;&#x7684;&#x675f;&#x7f1a;"/>
<node CREATED="1366590380553" ID="ID_1753320044" MODIFIED="1394122170120" TEXT="&#x300c;run it&#x4f18;&#x5148;&#x300d;&#x80fd;&#x5feb;&#x901f;&#x8fed;&#x4ee3;&#x51fa;&#x4f1f;&#x5927;&#x7684;v1"/>
</node>
<node CREATED="1366590649560" ID="ID_898491592" MODIFIED="1366590655042" TEXT="&#x4e00;&#x4e2a;&#x5b57;&#x603b;&#x7ed3;">
<node CREATED="1366590656030" ID="ID_402097752" MODIFIED="1366590658372" TEXT="&#x7f8e;"/>
</node>
</node>
</node>
<node CREATED="1373879919833" ID="ID_1937859722" MODIFIED="1438940731234" TEXT="&#x725b;&#x4eba;1,2,3">
<node CREATED="1373879925252" ID="ID_297237862" MODIFIED="1373879965058" TEXT="1&#x7814;&#x7a76;&#xff1a;&#x7814;&#x7a76;&#x4e1c;&#x897f;&#xff0c;&#x6709;&#x8db3;&#x591f;&#x6d1e;&#x5bdf;&#x529b;&#xff0c;&#x7814;&#x7a76;&#x6c34;&#x51c6;&#x4e0d;&#x9519;"/>
<node CREATED="1373879965508" ID="ID_262282109" MODIFIED="1438786330519" TEXT="2&#x7814;&#x53d1;&#xff1a;Hack Idea&#x81ea;&#x5df1;&#x6709;&#x9b44;&#x529b;&#x5b9e;&#x73b0;&#xff0c;&#x4e0d;&#x61c2;&#x7814;&#x53d1;&#x7684;&#x9ed1;&#x5ba2;&#x5982;&#x540c;&#x4e0d;&#x4f1a;&#x6e38;&#x6cf3;&#x7684;&#x6d77;&#x76d7;"/>
<node CREATED="1373880073900" ID="ID_1052039844" MODIFIED="1373880107120" TEXT="3&#x5de5;&#x7a0b;&#xff1a;&#x7814;&#x53d1;&#x51fa;&#x6765;&#x7684;&#x9700;&#x8981;&#x5b9e;&#x6218;&#x3001;&#x9700;&#x8981;&#x5de5;&#x7a0b;&#x5316;&#xff0c;&#x5426;&#x5219;&#x53ea;&#x662f;&#x73a9;&#x5177;&#xff0c;&#x800c;&#x4e0d;&#x80fd;&#x6210;&#x4e3a;&#x771f;&#x7684;&#x6b66;&#x5668;"/>
</node>
</node>
<node CREATED="1394163014498" ID="ID_944208754" MODIFIED="1438787855356" POSITION="right" TEXT="&#x4f18;&#x8d28;&#x8d44;&#x6e90;">
<node CREATED="1439028539431" ID="ID_1668072232" MODIFIED="1439028542738" TEXT="&#x4e66;">
<node CREATED="1439028549843" ID="ID_67318882" MODIFIED="1439028805473" TEXT="&#x591a;&#x5173;&#x6ce8;&#x7535;&#x5b50;&#x5de5;&#x4e1a;/&#x56fe;&#x7075;/&#x673a;&#x68b0;&#x5de5;&#x4e1a;/&#x4eba;&#x6c11;&#x90ae;&#x7535;&#x7b49;&#x51fa;&#x7248;&#x793e;&#xff0c;&#x4ed6;&#x4eec;&#x6709;&#x4e13;&#x4e1a;&#x56e2;&#x961f;&#x6765;&#x4fdd;&#x969c;&#x6bcf;&#x5e74;&#x8f93;&#x51fa;&#x4f18;&#x8d28;&#x4e66;&#x7c4d;"/>
<node CREATED="1439028816748" ID="ID_1618336034" MODIFIED="1439028833491" TEXT="&#x81ea;&#x5df1;&#x9700;&#x8981;&#x638c;&#x63e1;&#x9274;&#x522b;&#x597d;&#x4e66;&#x7684;&#x80fd;&#x529b;"/>
</node>
<node CREATED="1438413886683" ID="ID_1170708824" MODIFIED="1438787875258" TEXT="&#x7ad9;&#x70b9;">
<node CREATED="1394163407746" ID="ID_1560529546" LINK="http://zhuanlan.zhihu.com/Weekly" MODIFIED="1394165054486" TEXT="&#x77e5;&#x4e4e;&#x5468;&#x520a;&#xff1a;http://zhuanlan.zhihu.com/Weekly"/>
<node CREATED="1394163026134" ID="ID_1411509196" LINK="http://weekly.manong.io/" MODIFIED="1394165048120" TEXT="&#x7801;&#x519c;&#x5468;&#x520a;&#xff1a;http://weekly.manong.io/"/>
<node CREATED="1394164303391" ID="ID_952571271" LINK="http://pycoders.com/archive/" MODIFIED="1394165041061" TEXT="Pycoder&apos;s Weekly&#xff1a;http://pycoders.com/archive/"/>
<node CREATED="1394164141663" ID="ID_1524847256" LINK="https://news.ycombinator.com/" MODIFIED="1394165032797" TEXT="Hacker News&#xff1a;https://news.ycombinator.com/"/>
<node CREATED="1394163053660" ID="ID_563848945" LINK="http://news.dbanotes.net/" MODIFIED="1394165078718" TEXT="Startup News&#xff1a;http://news.dbanotes.net/"/>
<node CREATED="1438786583042" ID="ID_1455384354" LINK="http://toutiao.io/" MODIFIED="1440639816844" TEXT="&#x5f00;&#x53d1;&#x8005;&#x5934;&#x6761;&#xff1a;http://toutiao.io/"/>
<node CREATED="1394163483711" ID="ID_678498909" LINK="http://geek.csdn.net/" MODIFIED="1394165018010" TEXT="&#x6781;&#x5ba2;&#x5934;&#x6761;&#xff1a;http://geek.csdn.net/"/>
<node CREATED="1394164169044" ID="ID_1264944187" LINK="http://www.infoq.com/cn" MODIFIED="1394165011930" TEXT="InfoQ&#xff1a;http://www.infoq.com/cn"/>
<node CREATED="1394164196656" ID="ID_254874317" LINK="http://stackoverflow.com/" MODIFIED="1394165005602" TEXT="Stack Overflow&#xff1a;http://stackoverflow.com/"/>
<node CREATED="1394164223863" ID="ID_11264889" LINK="https://github.com/" MODIFIED="1394164999048" TEXT="GitHub&#xff1a;https://github.com/"/>
<node CREATED="1394163248895" ID="ID_1648180595" LINK="http://www.freebuf.com/" MODIFIED="1394164992265" TEXT="FreeBuf&#xff1a;http://www.freebuf.com/"/>
<node CREATED="1394164347334" ID="ID_236031405" LINK="http://drops.wooyun.org/" MODIFIED="1394164970143" TEXT="WooYun&#xff1a;http://drops.wooyun.org/"/>
<node CREATED="1438786535199" ID="ID_592864568" LINK="http://bluereader.org/" MODIFIED="1438786557356" TEXT="&#x6df1;&#x84dd;&#x9605;&#x8bfb;&#xff1a;http://bluereader.org/"/>
</node>
<node CREATED="1438407550812" ID="ID_821959318" MODIFIED="1438592561809" TEXT="RSS&#x8ba2;&#x9605;">
<node CREATED="1438407682181" ID="ID_514594876" MODIFIED="1438407685528" TEXT="&#x6f0f;&#x6d1e;&#x76f8;&#x5173;">
<node CREATED="1438407626480" ID="ID_1507091513" LINK="http://seebug.org/rss.xml " MODIFIED="1463562383596" TEXT="http://seebug.org/rss.xml"/>
<node CREATED="1438407559889" ID="ID_1039020164" LINK="https://www.exploit-db.com/rss.xml " MODIFIED="1438787195732" TEXT="https://www.exploit-db.com/rss.xml"/>
<node CREATED="1438407593859" ID="ID_1288792092" LINK="https://rss.packetstormsecurity.com " MODIFIED="1438787198679" TEXT="https://rss.packetstormsecurity.com"/>
<node CREATED="1438407601206" ID="ID_829431299" LINK="http://www.wooyun.org/feeds/public " MODIFIED="1438787203015" TEXT="http://www.wooyun.org/feeds/public"/>
</node>
<node CREATED="1438786619080" ID="ID_1734259109" MODIFIED="1438786630145" TEXT="&#x5f3a;&#x70c8;&#x63a8;&#x8350;&#x5708;&#x5185;&#x4eba;&#x6253;&#x9020;&#x7684;&#x6df1;&#x84dd;&#x9605;&#x8bfb;">
<node CREATED="1438786632080" ID="ID_224192456" LINK="http://bluereader.org/" MODIFIED="1438786641924" TEXT="http://bluereader.org/"/>
<node CREATED="1438940566009" ID="ID_608037455" MODIFIED="1438940587976" TEXT="&#x8fd9;&#x4e0a;&#x9762;&#x5df2;&#x7ecf;&#x5f88;&#x591a;&#x9ed1;&#x5ba2;/&#x6280;&#x672f;&#x7c7b;&#x4f3c;&#x7684;RSS&#x8d44;&#x6e90;&#x4e86;"/>
</node>
</node>
<node CREATED="1438789029172" ID="ID_408679105" MODIFIED="1438789034997" TEXT="&#x5a01;&#x80c1;&#x60c5;&#x62a5;">
<node CREATED="1438789036306" ID="ID_793394786" MODIFIED="1438789071461" TEXT="&#x672c;&#x6765;&#x4e0d;&#x60f3;&#x63d0;&#x4efb;&#x4f55;&#x8fd9;&#x65b9;&#x9762;&#x7684;&#xff0c;&#x60f3;&#x60f3;&#x8fd8;&#x662f;&#x6296;&#x4e2a;&#x8d44;&#x6e90;&#xff0c;&#x5982;&#x4e0b;"/>
<node CREATED="1438789061248" ID="ID_1842355563" LINK="https://github.com/kbandla/APTnotes " MODIFIED="1439030639609" TEXT="https://github.com/kbandla/APTnotes"/>
</node>
<node CREATED="1438407853531" ID="ID_575955218" MODIFIED="1438414209662" TEXT="&#x5b89;&#x5168;&#x5e73;&#x53f0;">
<node CREATED="1438410167391" ID="ID_1554574113" MODIFIED="1439031243599" TEXT="&#x5728;&#x7ebf;&#x5b66;&#x4e60;&#x5e73;&#x53f0;">
<node CREATED="1438410097216" ID="ID_1977776821" LINK="http://www.ichunqiu.com" MODIFIED="1439031288148" TEXT="i&#x6625;&#x79cb;&#xff1a;http://www.ichunqiu.com"/>
<node CREATED="1438410271173" ID="ID_626979305" LINK="https://pentesterlab.com" MODIFIED="1438410278381" TEXT="https://pentesterlab.com"/>
</node>
<node CREATED="1438410163637" ID="ID_972435194" MODIFIED="1438786764748" TEXT="PoC&#x63d0;&#x4ea4;&#x4e0e;&#x5b66;&#x4e60;">
<node CREATED="1438410362802" ID="ID_1111372182" LINK="http://seebug.org" MODIFIED="1463562313472" TEXT="Seebug: http://seebug.org"/>
<node CREATED="1438410423943" ID="ID_1008897807" LINK="http://www.beebeeto.com" MODIFIED="1439030622803" TEXT="Beebeeto: http://www.beebeeto.com"/>
<node CREATED="1438410379515" ID="ID_1691210129" LINK="http://www.bugscan.net" MODIFIED="1439030615996" TEXT="Bugscan: http://www.bugscan.net"/>
<node CREATED="1438410401653" ID="ID_544729193" LINK="http://www.tangscan.com" MODIFIED="1439030609625" TEXT="Tangscan: http://www.tangscan.com"/>
</node>
</node>
</node>
<node CREATED="1439029037427" ID="ID_1662653025" MODIFIED="1439029057213" POSITION="right" TEXT="&#x7ed3;&#x5c3e;">
<node CREATED="1439029066024" ID="ID_172485861" MODIFIED="1439029121897" TEXT="&#x672c;&#x6280;&#x80fd;&#x8868;&#x4f1a;&#x6301;&#x7eed;&#x4e0d;&#x65ad;&#x66f4;&#x65b0;"/>
<node CREATED="1438789159311" ID="ID_1649023462" MODIFIED="1439028936281" TEXT="&#x5982;&#x679c;&#x6709;&#x76f8;&#x5173;&#x597d;&#x8d44;&#x6e90;/&#x5efa;&#x8bae;&#x53ef;&#x4ee5;&#x8054;&#x7cfb;&#x6211;&#xff1a;evilcos@gmail.com"/>
<node CREATED="1439029129446" ID="ID_1156700364" MODIFIED="1439029469418" TEXT="&#x5982;&#x679c;&#x672c;&#x6280;&#x80fd;&#x8868;&#x5f15;&#x8d77;&#x4f60;&#x7684;&#x5f3a;&#x70c8;&#x5171;&#x9e23;&#xff0c;&#x60f3;&#x52a0;&#x5165;&#x6211;&#x4eec;&#xff0c;&#x53ef;&#x4ee5;&#x8054;&#x7cfb;&#x6211;&#xff1a;evilcos@gmail.com&#xff0c;&#x6211;&#x4f1a;&#x7ed3;&#x5408;&#x4f60;&#x7684;&#x60c5;&#x51b5;">
<node CREATED="1439029265934" ID="ID_1124985287" MODIFIED="1439029327108" TEXT="&#x7ed9;&#x4f60;&#x4ec5;&#x4ec5;&#x4e00;&#x9053;&#x6709;&#x8da3;&#x7684;&#x7b14;&#x8bd5;&#x9898;"/>
<node CREATED="1439029287854" ID="ID_1479348869" MODIFIED="1439029310587" TEXT="&#x6216;&#x8005;&#x548c;&#x4f60;&#x7ebf;&#x4e0b;&#x7ea6;&#x804a;"/>
</node>
<node CREATED="1439029477258" ID="ID_857014223" MODIFIED="1439029508170" TEXT="&#x90ae;&#x4ef6;&#x8054;&#x7cfb;&#x6211;&#xff0c;&#x90ae;&#x4ef6;&#x6807;&#x9898;&#x52a1;&#x5fc5;&#x5305;&#x542b;&#x300c;&#x6280;&#x80fd;&#x8868;&#x300d;&#x4e09;&#x4e2a;&#x5b57;&#xff0c;&#x611f;&#x8c22;">
<icon BUILTIN="messagebox_warning"/>
</node>
<node COLOR="#990000" CREATED="1439029423769" ID="ID_339795998" MODIFIED="1439029450774" TEXT="TO BE A HACKER:)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</map>
